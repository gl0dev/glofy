"use client"

import { useTheme, backgroundStyles } from "@/contexts/theme-context"

interface DynamicBackgroundProps {
  mousePosition?: { x: number; y: number }
}

export function DynamicBackground({ mousePosition = { x: 0, y: 0 } }: DynamicBackgroundProps) {
  const { currentTheme } = useTheme()

  const backgroundStyle = backgroundStyles.find((style) => style.id === currentTheme.backgroundStyle)
  const BackgroundComponent = backgroundStyle?.component

  if (!BackgroundComponent) {
    return <div className="absolute inset-0" style={{ background: currentTheme.gradients.background }} />
  }

  return (
    <div className="absolute inset-0 overflow-hidden">
      <BackgroundComponent theme={currentTheme} />

      {/* Interactive mouse-following elements for enhanced interactivity */}
      <div
        className="absolute w-96 h-96 rounded-full blur-3xl opacity-10 pointer-events-none transition-transform duration-1000 ease-out"
        style={{
          background: currentTheme.gradients.primary,
          transform: `translate(${mousePosition.x * 0.02}px, ${mousePosition.y * 0.02}px)`,
          left: "10%",
          top: "20%",
        }}
      />
      <div
        className="absolute w-80 h-80 rounded-full blur-3xl opacity-10 pointer-events-none transition-transform duration-1000 ease-out"
        style={{
          background: currentTheme.gradients.secondary,
          transform: `translate(${mousePosition.x * -0.01}px, ${mousePosition.y * -0.01}px)`,
          right: "10%",
          bottom: "20%",
        }}
      />
    </div>
  )
}
