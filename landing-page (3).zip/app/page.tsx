"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { ArrowRight, AlertCircle, Loader2, Sparkles } from "lucide-react"
import { useAuth } from "@/hooks/useAuth"
import { Dashboard } from "@/components/dashboard"
import { useTheme } from "@/contexts/theme-context"
import { DynamicBackground } from "@/components/dynamic-background"

export default function LandingPage() {
  const { isAuthenticated, loading, enterKey } = useAuth()
  const { currentTheme, isDarkMode } = useTheme()
  const [accessKey, setAccessKey] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  const handleKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!accessKey.trim() || isLoading) return

    setIsLoading(true)
    setError(null)

    const { success, error } = await enterKey(accessKey)

    if (!success && error) {
      setError(error.message)
      setAccessKey("")
    }

    setIsLoading(false)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAccessKey(e.target.value)
    setError(null)
  }

  // Show loading spinner while checking auth state
  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: currentTheme.gradients.background }}
      >
        <div
          className="w-8 h-8 border-4 border-t-4 rounded-full animate-spin"
          style={{
            borderColor: `${currentTheme.colors.primary}20`,
            borderTopColor: currentTheme.colors.primary,
          }}
        />
      </div>
    )
  }

  // Show dashboard if user is authenticated
  if (isAuthenticated) {
    return <Dashboard />
  }

  return (
    <div className="min-h-screen relative overflow-hidden w-full">
      {/* Dynamic Background */}
      <DynamicBackground mousePosition={mousePosition} />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 w-full">
        {/* Logo */}
        <div className="mb-12 sm:mb-16 text-center w-full max-w-4xl">
          <div className="space-y-4 sm:space-y-6">
            <div className="glass-button inline-flex items-center gap-2 px-3 sm:px-4 lg:px-5 py-2 lg:py-2.5">
              <Sparkles className="w-4 h-4 lg:w-5 lg:h-5 text-white" />
              <span className="text-sm lg:text-base font-medium text-white">AI assistant</span>
            </div>

            <div className="py-2 sm:py-4">
              <h1
                className="text-5xl sm:text-6xl lg:text-7xl font-bold bg-clip-text text-transparent leading-tight"
                style={{
                  backgroundImage: currentTheme.gradients.primary,
                  lineHeight: "1.1",
                  paddingTop: "0.1em",
                  paddingBottom: "0.1em",
                }}
              >
                Glofy
              </h1>
            </div>
          </div>
        </div>

        {/* Access Key Form - Centered and Mobile Optimized */}
        <div className="w-full flex flex-col items-center space-y-4 sm:space-y-6 max-w-md mx-auto px-4">
          {/* Error Message */}
          {error && (
            <div className="flex items-center justify-center gap-3 p-3 sm:p-4 rounded-2xl glass-welcome-card animate-in slide-in-from-top-4 duration-300 w-full">
              <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 text-red-600 dark:text-red-400" />
              <p className="text-sm font-medium text-center text-red-600 dark:text-red-400">{error}</p>
            </div>
          )}

          {/* Input Form - Mobile Optimized */}
          <form onSubmit={handleKeySubmit} className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 w-full">
            {/* Access Key Input - Glass effect with proper text color */}
            <Input
              type="password"
              placeholder="Access Key"
              value={accessKey}
              onChange={handleInputChange}
              className="glass-input w-full sm:w-80 h-14 sm:h-16 px-4 sm:px-6 text-base sm:text-lg font-mono tracking-wider text-center transition-all duration-300 focus:scale-[1.02]"
              style={{
                color: currentTheme.colors.text,
                fontSize: "16px", // Critical for preventing zoom
                lineHeight: "1.5",
                WebkitAppearance: "none",
                MozAppearance: "none",
                appearance: "none",
              }}
              required
              autoFocus
              autoComplete="off"
              inputMode="text"
            />

            {/* Enter Button - Glass effect with theme colors */}
            <button
              type="submit"
              disabled={isLoading || !accessKey.trim()}
              className="glass-button h-14 w-14 sm:h-16 sm:w-16 rounded-2xl disabled:opacity-50 group relative overflow-hidden flex-shrink-0 flex items-center justify-center"
              style={{
                fontSize: "16px", // Prevent zoom
                touchAction: "manipulation",
              }}
            >
              {/* Button shine effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />

              <div className="relative z-10">
                {isLoading ? (
                  <Loader2 className="w-5 h-5 sm:w-6 sm:h-6 text-white animate-spin" />
                ) : (
                  <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:translate-x-0.5 transition-transform duration-300" />
                )}
              </div>
            </button>
          </form>

          {/* Security Indicator */}
          <div className="flex items-center justify-center gap-2 text-sm">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span style={{ color: currentTheme.colors.textSecondary }}>Secure Connection</span>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 sm:mt-16 text-center">
          <p className="text-sm" style={{ color: currentTheme.colors.textMuted }}>
            Enter your access key to continue
          </p>
        </div>
      </div>
    </div>
  )
}
