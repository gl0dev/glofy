"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { X, Layers, Check, Sparkles, Circle, Waves, Palette } from "lucide-react"
import { useTheme, backgroundStyles } from "@/contexts/theme-context"

interface StylesDashboardProps {
  isOpen: boolean
  onClose: () => void
}

const backgroundIcons = {
  gradient: Layers,
  pattern: Circle,
  waves: Waves,
  mesh: Palette,
  grid: Layers,
}

export function StylesDashboard({ isOpen, onClose }: StylesDashboardProps) {
  const { currentTheme, updateBackgroundStyle } = useTheme()

  const handleBackgroundStyleChange = (styleId: string) => {
    updateBackgroundStyle(styleId)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={onClose} />

      {/* Dashboard */}
      <div className="relative ml-auto h-full w-96 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-l border-white/30 dark:border-gray-700/30 shadow-2xl overflow-hidden">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200/50 dark:border-gray-700/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center">
                <Layers className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Styles</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">Choose background styles</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-10 w-10 p-0 rounded-full text-gray-500 dark:text-gray-400"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Background Styles</h3>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                Current: {backgroundStyles.find((s) => s.id === currentTheme.backgroundStyle)?.name}
              </div>
            </div>

            <div className="grid gap-3">
              {backgroundStyles.map((style) => {
                const IconComponent = backgroundIcons[style.type as keyof typeof backgroundIcons] || Layers
                const isActive = currentTheme.backgroundStyle === style.id

                return (
                  <Card
                    key={style.id}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                      isActive
                        ? "ring-2 ring-purple-500 bg-purple-50/50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-700"
                        : "bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-white/30 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90"
                    }`}
                    onClick={() => handleBackgroundStyleChange(style.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-12 h-12 rounded-lg flex items-center justify-center text-white relative overflow-hidden"
                            style={{ background: currentTheme.gradients.primary }}
                          >
                            <IconComponent className="w-5 h-5 relative z-10" />
                            {/* Mini preview of the background style */}
                            <div className="absolute inset-0 opacity-30">
                              {style.id === "pattern" && (
                                <div
                                  className="absolute inset-0"
                                  style={{
                                    backgroundImage: `radial-gradient(circle at 25% 25%, white 1px, transparent 1px), radial-gradient(circle at 75% 75%, white 1px, transparent 1px)`,
                                    backgroundSize: "8px 8px",
                                  }}
                                />
                              )}
                              {style.id === "waves" && (
                                <svg
                                  className="absolute inset-0 w-full h-full"
                                  viewBox="0 0 100 100"
                                  preserveAspectRatio="none"
                                >
                                  <path
                                    fill="white"
                                    fillOpacity="0.3"
                                    d="M0,50 Q25,30 50,50 T100,50 L100,100 L0,100 Z"
                                  />
                                </svg>
                              )}
                              {style.id === "mesh" && (
                                <>
                                  <div className="absolute top-0 left-0 w-4 h-4 bg-white/20 rounded-full blur-sm" />
                                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-white/20 rounded-full blur-sm" />
                                </>
                              )}
                              {style.id === "grid" && (
                                <div
                                  className="absolute inset-0"
                                  style={{
                                    backgroundImage: `linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)`,
                                    backgroundSize: "8px 8px",
                                  }}
                                />
                              )}
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 dark:text-gray-100">{style.name}</h4>
                            <p className="text-xs text-gray-600 dark:text-gray-400 capitalize">{style.type} style</p>
                          </div>
                        </div>
                        {isActive && <Check className="w-5 h-5 text-purple-600" />}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="mt-6 p-4 bg-purple-50/50 dark:bg-purple-900/20 rounded-lg border border-purple-200/50 dark:border-purple-700/50">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-purple-900 dark:text-purple-100">Pro Tip</h4>
                  <p className="text-sm text-purple-700 dark:text-purple-300 mt-1">
                    Background styles automatically adapt to your color theme. Try changing colors to see how they
                    affect the patterns!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
