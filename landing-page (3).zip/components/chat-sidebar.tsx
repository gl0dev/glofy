"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MessageCircle, Plus, Trash2, MoreHorizontal } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"
import { useChats } from "@/hooks/useChats"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface ChatSidebarProps {
  isOpen: boolean
  onClose: () => void
  onChatSelect?: (chatId: string) => void
}

export function ChatSidebar({ isOpen, onClose, onChatSelect }: ChatSidebarProps) {
  const { currentTheme } = useTheme()
  const { chats, currentChatId, createNewChat, switchToChat, deleteChat } = useChats()

  const handleNewChat = () => {
    createNewChat()
  }

  const handleChatSelect = (chatId: string) => {
    switchToChat(chatId)
    if (onChatSelect) {
      onChatSelect(chatId)
    }
  }

  const handleDeleteChat = (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    deleteChat(chatId)
  }

  const formatDate = (date: Date) => {
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 24 * 7) {
      return date.toLocaleDateString([], { weekday: "short" })
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" })
    }
  }

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop - only covers the sidebar area */}
      <div className="fixed inset-0 bg-black/10 backdrop-blur-[1px] z-40" onClick={onClose} />

      {/* Sidebar - slides in from right */}
      <div className="fixed right-0 top-0 w-80 h-full bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border-l border-white/30 dark:border-gray-700/30 shadow-2xl overflow-hidden z-50 transform transition-transform duration-300 ease-out">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200/50 dark:border-gray-700/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Chat History</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {chats.length} conversation{chats.length !== 1 ? "s" : ""}
                </p>
              </div>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="h-10 w-10 p-0 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              ×
            </Button>
          </div>

          {/* New Chat Button */}
          <div className="p-4">
            <Button
              onClick={handleNewChat}
              className="w-full text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
              style={{ background: currentTheme.gradients.primary }}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          </div>

          {/* Chat List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
            {chats.length === 0 ? (
              <div className="text-center py-8">
                <MessageCircle
                  className="w-12 h-12 mx-auto mb-4 opacity-50"
                  style={{ color: currentTheme.colors.textMuted }}
                />
                <p className="text-sm" style={{ color: currentTheme.colors.textMuted }}>
                  No chats yet. Start a new conversation!
                </p>
              </div>
            ) : (
              chats.map((chat) => (
                <Card
                  key={chat.id}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg group ${
                    currentChatId === chat.id
                      ? "ring-2 ring-blue-500 bg-blue-50/50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700"
                      : "bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-white/30 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90"
                  }`}
                  onClick={() => handleChatSelect(chat.id)}
                >
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm text-gray-900 dark:text-gray-100 truncate mb-1">
                          {chat.title}
                        </h4>
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {chat.messages.length - 1} message{chat.messages.length - 1 !== 1 ? "s" : ""}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-500">{formatDate(chat.updatedAt)}</p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={(e) => handleDeleteChat(chat.id, e)}
                            className="text-red-600 dark:text-red-400"
                          >
                            <Trash2 className="w-3 h-3 mr-2" />
                            Delete Chat
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </>
  )
}
