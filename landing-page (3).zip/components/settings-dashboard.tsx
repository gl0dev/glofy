"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useTheme } from "@/contexts/theme-context"
import { Palette, Layers, Moon, Sun, User, HelpCircle } from "lucide-react"

interface SettingsDashboardProps {
  onColorSettings: () => void
  onStyleSettings: () => void
  onProfileSettings: () => void
}

export function SettingsDashboard({ onColorSettings, onStyleSettings, onProfileSettings }: SettingsDashboardProps) {
  const { currentTheme, isDarkMode, toggleDarkMode } = useTheme()

  const settingsCategories = [
    {
      title: "Appearance",
      icon: Palette,
      items: [
        {
          label: "Color Themes",
          description: "Customize your color palette",
          icon: Palette,
          action: onColorSettings,
        },
        {
          label: "Background Styles",
          description: "Choose your background pattern",
          icon: Layers,
          action: onStyleSettings,
        },
        {
          label: isDarkMode ? "Light Mode" : "Dark Mode",
          description: `Switch to ${isDarkMode ? "light" : "dark"} theme`,
          icon: isDarkMode ? Sun : Moon,
          action: toggleDarkMode,
        },
      ],
    },
    {
      title: "Account",
      icon: User,
      items: [
        {
          label: "Profile Settings",
          description: "Manage your profile information and access key",
          icon: User,
          action: onProfileSettings,
        },
      ],
    },
    {
      title: "Support",
      icon: HelpCircle,
      items: [
        {
          label: "Help Center",
          description: "Get help and support",
          icon: HelpCircle,
          action: () => {},
        },
      ],
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2" style={{ color: currentTheme.colors.text }}>
          Settings
        </h2>
        <p className="text-sm" style={{ color: currentTheme.colors.textSecondary }}>
          Customize your Glofy experience
        </p>
      </div>

      {settingsCategories.map((category, categoryIndex) => (
        <Card
          key={categoryIndex}
          className="backdrop-blur-xl shadow-xl border"
          style={{
            backgroundColor: `${currentTheme.colors.surface}70`,
            borderColor: `${currentTheme.colors.border}30`,
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2" style={{ color: currentTheme.colors.text }}>
              <category.icon className="w-5 h-5" />
              {category.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {category.items.map((item, itemIndex) => (
              <div key={itemIndex}>
                <Button
                  variant="ghost"
                  onClick={item.action}
                  className="w-full justify-start p-4 h-auto rounded-xl hover:bg-opacity-50"
                  style={{ color: currentTheme.colors.textSecondary }}
                >
                  <div className="flex items-center gap-3 w-full">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${currentTheme.colors.primary}20` }}
                    >
                      <item.icon className="w-5 h-5" style={{ color: currentTheme.colors.primary }} />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium" style={{ color: currentTheme.colors.text }}>
                        {item.label}
                      </p>
                      <p className="text-xs" style={{ color: currentTheme.colors.textMuted }}>
                        {item.description}
                      </p>
                    </div>
                  </div>
                </Button>
                {itemIndex < category.items.length - 1 && (
                  <Separator className="my-2" style={{ backgroundColor: `${currentTheme.colors.border}30` }} />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
