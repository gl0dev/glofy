import { streamText } from "ai"
import { xai } from "@ai-sdk/xai"

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Get the last user message for search enhancement
    const lastMessage = messages[messages.length - 1]
    const userInput = lastMessage?.content || ""

    // Determine if we need real-time information
    const needsRealTimeInfo = shouldUseRealTimeSearch(userInput)

    let enhancedMessages = messages

    if (needsRealTimeInfo) {
      // Use Gemini for real-time web search and information
      const searchResults = await getGeminiWebSearch(userInput)

      if (searchResults) {
        // Add search context to the conversation
        const searchContext = `Based on current web search results:\n${searchResults}\n\nUser question: ${userInput}`

        // Replace the last user message with enhanced version
        enhancedMessages = [...messages]
        enhancedMessages[enhancedMessages.length - 1] = {
          ...enhancedMessages[enhancedMessages.length - 1],
          content: searchContext,
        }
      }
    }

    // Use Glofy-1 for the AI response with enhanced context
    const result = streamText({
      model: xai("grok-3"),
      messages: enhancedMessages,
      system: `You are Glofy, an advanced AI productivity assistant powered by Glofy-1 and enhanced with real-time web search capabilities through Google's Gemini AI.

Key capabilities:
- Real-time web information and current events via Google search
- Productivity optimization and task management
- Creative problem solving and brainstorming
- Technical assistance and coding help
- Goal setting and achievement strategies
- Workflow automation suggestions
- Access to current news, trends, and factual information

Your personality:
- Enthusiastic and energetic about helping users
- Direct and practical in your advice
- Creative and innovative in your solutions
- Supportive and encouraging
- Always up-to-date with current information from the web

When you receive web search results, integrate them naturally into your responses and always cite your sources. Be clear when information comes from real-time web searches vs your training data. Provide accurate, current information based on the search results.`,
      temperature: 0.7,
      maxTokens: 1000,
    })

    // Convert the result to the expected streaming format
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const delta of result.textStream) {
            const chunk = `0:${JSON.stringify({ type: "text-delta", textDelta: delta })}\n`
            controller.enqueue(encoder.encode(chunk))
          }
          controller.close()
        } catch (error) {
          console.error("Streaming error:", error)
          const errorChunk = `0:${JSON.stringify({ type: "text-delta", textDelta: "I apologize, but I'm having trouble generating a response right now. Please try again." })}\n`
          controller.enqueue(encoder.encode(errorChunk))
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Transfer-Encoding": "chunked",
      },
    })
  } catch (error) {
    console.error("Chat API error:", error)
    return new Response(JSON.stringify({ error: "AI service temporarily unavailable. Please try again." }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

function shouldUseRealTimeSearch(input: string): boolean {
  const searchTriggers = [
    // Current events and news
    "latest",
    "recent",
    "current",
    "today",
    "news",
    "update",
    "what happened",
    "breaking",
    "now",
    "this week",
    "this month",
    "2024",
    "2025",

    // Factual queries that need current info
    "what is",
    "who is",
    "when did",
    "where is",
    "how much",
    "statistics",
    "price",
    "cost",
    "stock",
    "market",
    "weather",
    "temperature",

    // Trends and popular topics
    "trend",
    "trending",
    "popular",
    "best",
    "top",
    "ranking",
    "viral",
    "most",
    "fastest",
    "biggest",
    "largest",
    "smallest",

    // Technology and tools (often updated)
    "new",
    "release",
    "version",
    "update",
    "launch",
    "announce",
    "software",
    "app",
    "technology",
    "tool",
    "platform",

    // Research and learning (current info)
    "research",
    "study",
    "report",
    "survey",
    "data",
    "findings",
    "discover",
    "breakthrough",
    "innovation",

    // Business and finance
    "earnings",
    "revenue",
    "profit",
    "loss",
    "ipo",
    "merger",
    "acquisition",
    "investment",
    "funding",
    "valuation",

    // Sports and entertainment
    "score",
    "game",
    "match",
    "tournament",
    "championship",
    "movie",
    "show",
    "series",
    "album",
    "song",
    "concert",

    // Health and science
    "vaccine",
    "treatment",
    "cure",
    "disease",
    "outbreak",
    "clinical trial",
    "fda",
    "approval",
    "medicine",

    // Politics and world events
    "election",
    "vote",
    "poll",
    "government",
    "policy",
    "war",
    "conflict",
    "peace",
    "treaty",
    "summit",
  ]

  const lowerInput = input.toLowerCase()
  return searchTriggers.some((trigger) => lowerInput.includes(trigger))
}

async function getGeminiWebSearch(query: string): Promise<string | null> {
  try {
    const apiKey = "AIzaSyB0PxABTRkxEBmEUZWb_mFhvvj8kACahLM"

    if (!apiKey) {
      console.warn("Gemini API key not configured")
      return null
    }

    console.log("Performing Gemini web search for:", query)

    // Direct API call to Gemini with proper endpoint
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Search the web and provide current, accurate information about: "${query}". 

Please provide:
1. Current facts and data
2. Recent developments or news
3. Reliable sources and dates when possible
4. Key statistics or numbers if relevant

Focus on accuracy and recency. If this is about current events, include the latest information available.`,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 800,
            topK: 40,
            topP: 0.95,
          },
          safetySettings: [
            {
              category: "HARM_CATEGORY_HARASSMENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE",
            },
            {
              category: "HARM_CATEGORY_HATE_SPEECH",
              threshold: "BLOCK_MEDIUM_AND_ABOVE",
            },
            {
              category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE",
            },
            {
              category: "HARM_CATEGORY_DANGEROUS_CONTENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE",
            },
          ],
        }),
      },
    )

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Gemini API error: ${response.status} ${response.statusText}`, errorText)
      return null
    }

    const data = await response.json()

    if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) {
      const searchResults = data.candidates[0].content.parts[0].text
      if (searchResults && searchResults.trim()) {
        console.log("Gemini web search successful")
        return searchResults
      }
    }

    console.warn("No valid response from Gemini search")
    return null
  } catch (error) {
    console.error("Gemini web search error:", error)
    return null
  }
}
