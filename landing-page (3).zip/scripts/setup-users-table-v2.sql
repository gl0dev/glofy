-- Drop existing functions and triggers
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS sign_in_with_username(TEXT, TEXT);
DROP FUNCTION IF EXISTS check_username_available(TEXT);

-- Create a custom users table for username-based authentication
DROP TABLE IF EXISTS public.user_profiles;
CREATE TABLE public.user_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create an index on username for faster lookups
CREATE INDEX idx_user_profiles_username ON public.user_profiles(username);

-- Enable RLS (Row Level Security)
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

-- Create policies for RLS
CREATE POLICY "Users can view their own profile" ON public.user_profiles
  FOR SELECT USING (true); -- Allow reading for now, we'll handle auth in the app

CREATE POLICY "Users can update their own profile" ON public.user_profiles
  FOR UPDATE USING (true);

CREATE POLICY "Users can insert their own profile" ON public.user_profiles
  FOR INSERT WITH CHECK (true);

-- Function to create a new user with username and password
CREATE OR REPLACE FUNCTION create_user_with_username(
  username_input TEXT,
  password_input TEXT,
  full_name_input TEXT
)
RETURNS JSON AS $$
DECLARE
  user_id UUID;
  password_hash TEXT;
BEGIN
  -- Check if username already exists
  IF EXISTS (SELECT 1 FROM public.user_profiles WHERE username = LOWER(username_input)) THEN
    RETURN json_build_object('success', false, 'message', 'Username is already taken');
  END IF;
  
  -- Hash the password (in a real app, this should be done client-side or with proper hashing)
  password_hash := crypt(password_input, gen_salt('bf'));
  
  -- Insert new user
  INSERT INTO public.user_profiles (username, full_name, password_hash)
  VALUES (LOWER(username_input), full_name_input, password_hash)
  RETURNING id INTO user_id;
  
  RETURN json_build_object(
    'success', true, 
    'user_id', user_id,
    'username', LOWER(username_input),
    'full_name', full_name_input
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN json_build_object('success', false, 'message', 'Failed to create user');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to authenticate user with username and password
CREATE OR REPLACE FUNCTION authenticate_user(
  username_input TEXT,
  password_input TEXT
)
RETURNS JSON AS $$
DECLARE
  user_record RECORD;
BEGIN
  -- Get user record
  SELECT id, username, full_name, password_hash, created_at
  INTO user_record
  FROM public.user_profiles 
  WHERE username = LOWER(username_input);
  
  -- Check if user exists and password is correct
  IF user_record.id IS NULL THEN
    RETURN json_build_object('success', false, 'message', 'Invalid username or password');
  END IF;
  
  -- Verify password
  IF user_record.password_hash = crypt(password_input, user_record.password_hash) THEN
    RETURN json_build_object(
      'success', true,
      'user', json_build_object(
        'id', user_record.id,
        'username', user_record.username,
        'full_name', user_record.full_name,
        'created_at', user_record.created_at
      )
    );
  ELSE
    RETURN json_build_object('success', false, 'message', 'Invalid username or password');
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check username availability
CREATE OR REPLACE FUNCTION check_username_available(username_input TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE username = LOWER(username_input)
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
