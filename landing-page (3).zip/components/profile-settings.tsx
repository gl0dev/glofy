"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { X, User, Key, Save, AlertCircle, CheckCircle, Eye, EyeOff } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"
import { useAuth } from "@/hooks/useAuth"

interface ProfileSettingsProps {
  isOpen: boolean
  onClose: () => void
}

export function ProfileSettings({ isOpen, onClose }: ProfileSettingsProps) {
  const { currentTheme } = useTheme()
  const { getCurrentUser, updateUserProfile } = useAuth()
  const currentUser = getCurrentUser()

  const [displayName, setDisplayName] = useState(currentUser.displayName)
  const [currentKey, setCurrentKey] = useState("")
  const [newKey, setNewKey] = useState("")
  const [confirmKey, setConfirmKey] = useState("")
  const [showCurrentKey, setShowCurrentKey] = useState(false)
  const [showNewKey, setShowNewKey] = useState(false)
  const [showConfirmKey, setShowConfirmKey] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  const handleSaveProfile = async () => {
    setIsLoading(true)
    setMessage(null)

    try {
      const result = await updateUserProfile({
        displayName: displayName.trim(),
        currentKey: currentKey.trim(),
        newKey: newKey.trim(),
        confirmKey: confirmKey.trim(),
      })

      if (result.success) {
        setMessage({ type: "success", text: "Profile updated successfully!" })
        setCurrentKey("")
        setNewKey("")
        setConfirmKey("")

        // Close the modal after a short delay
        setTimeout(() => {
          onClose()
        }, 1500)
      } else {
        setMessage({ type: "error", text: result.error || "Failed to update profile" })
      }
    } catch (error) {
      setMessage({ type: "error", text: "An unexpected error occurred" })
    } finally {
      setIsLoading(false)
    }
  }

  const isKeyChangeValid = () => {
    if (!newKey.trim()) return true // No key change requested
    return currentKey.trim() && newKey.trim() && confirmKey.trim() && newKey === confirmKey
  }

  const canSave = () => {
    const displayNameChanged = displayName.trim() !== currentUser.displayName
    const keyChangeRequested = newKey.trim() || confirmKey.trim() || currentKey.trim()

    if (!displayNameChanged && !keyChangeRequested) return false
    if (keyChangeRequested && !isKeyChangeValid()) return false

    return true
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative ml-auto h-full w-full max-w-md bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-l border-white/30 dark:border-gray-700/30 shadow-2xl overflow-hidden">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200/50 dark:border-gray-700/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Profile Settings</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">Manage your account information</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-10 w-10 p-0 rounded-full text-gray-500 dark:text-gray-400"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Success/Error Message */}
            {message && (
              <div
                className={`flex items-center gap-3 p-4 rounded-xl border ${
                  message.type === "success"
                    ? "bg-green-50/50 dark:bg-green-900/20 border-green-200 dark:border-green-700"
                    : "bg-red-50/50 dark:bg-red-900/20 border-red-200 dark:border-red-700"
                }`}
              >
                {message.type === "success" ? (
                  <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                )}
                <p
                  className={`text-sm font-medium ${
                    message.type === "success" ? "text-green-800 dark:text-green-200" : "text-red-800 dark:text-red-200"
                  }`}
                >
                  {message.text}
                </p>
              </div>
            )}

            {/* Display Name Section */}
            <Card className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-white/30 dark:border-gray-700/30">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2 text-gray-900 dark:text-gray-100">
                  <User className="w-5 h-5" />
                  Display Name
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="displayName" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Your display name
                  </Label>
                  <Input
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Enter your display name"
                    className="mt-1 bg-white/70 dark:bg-gray-800/70 border-gray-200/50 dark:border-gray-700/50"
                    maxLength={50}
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    This is how your name will appear in the app
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Access Key Section */}
            <Card className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-white/30 dark:border-gray-700/30">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2 text-gray-900 dark:text-gray-100">
                  <Key className="w-5 h-5" />
                  Change Access Key
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-amber-50/50 dark:bg-amber-900/20 rounded-lg border border-amber-200/50 dark:border-amber-700/50">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-amber-800 dark:text-amber-200">
                      Changing your access key will require you to use the new key for future logins. Keep it secure!
                    </p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="currentKey" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Current access key
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="currentKey"
                      type={showCurrentKey ? "text" : "password"}
                      value={currentKey}
                      onChange={(e) => setCurrentKey(e.target.value)}
                      placeholder="Enter your current access key"
                      className="pr-10 bg-white/70 dark:bg-gray-800/70 border-gray-200/50 dark:border-gray-700/50"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowCurrentKey(!showCurrentKey)}
                    >
                      {showCurrentKey ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="newKey" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    New access key
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="newKey"
                      type={showNewKey ? "text" : "password"}
                      value={newKey}
                      onChange={(e) => setNewKey(e.target.value)}
                      placeholder="Enter your new access key"
                      className="pr-10 bg-white/70 dark:bg-gray-800/70 border-gray-200/50 dark:border-gray-700/50"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowNewKey(!showNewKey)}
                    >
                      {showNewKey ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="confirmKey" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Confirm new access key
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="confirmKey"
                      type={showConfirmKey ? "text" : "password"}
                      value={confirmKey}
                      onChange={(e) => setConfirmKey(e.target.value)}
                      placeholder="Confirm your new access key"
                      className="pr-10 bg-white/70 dark:bg-gray-800/70 border-gray-200/50 dark:border-gray-700/50"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowConfirmKey(!showConfirmKey)}
                    >
                      {showConfirmKey ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                  </div>
                  {newKey && confirmKey && newKey !== confirmKey && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">Access keys do not match</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-gray-200/50 dark:border-gray-700/50">
            <div className="flex gap-3">
              <Button
                onClick={onClose}
                variant="outline"
                className="flex-1 bg-white/70 dark:bg-gray-800/70 border-gray-200/50 dark:border-gray-700/50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveProfile}
                disabled={!canSave() || isLoading}
                className="flex-1 text-white"
                style={{ background: currentTheme.gradients.primary }}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Saving...
                  </div>
                ) : (
                  <span className="flex items-center gap-2">
                    <Save className="w-4 h-4" />
                    Save Changes
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
