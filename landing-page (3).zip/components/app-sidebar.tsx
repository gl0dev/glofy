"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { LogOut, Settings, MessageCircle, Home, ChevronLeft, ChevronRight, X } from "lucide-react"
import { useAuth } from "@/hooks/useAuth"
import { useTheme } from "@/contexts/theme-context"

interface AppSidebarProps {
  activeView: "dashboard" | "chat" | "settings"
  onViewChange: (view: "dashboard" | "chat" | "settings") => void
  isMobile?: boolean
  onClose?: () => void
}

export function AppSidebar({ activeView, onViewChange, isMobile = false, onClose }: AppSidebarProps) {
  const { signOut, getCurrentUser } = useAuth()
  const { currentTheme, isDarkMode, toggleDarkMode } = useTheme()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const currentUser = getCurrentUser()

  const handleSignOut = async () => {
    await signOut()
  }

  const handleViewChange = (view: "dashboard" | "chat" | "settings") => {
    onViewChange(view)
    if (isMobile && onClose) {
      onClose()
    }
  }

  const sidebarWidth = isCollapsed && !isMobile ? "w-16" : "w-64"

  return (
    <>
      {/* Sidebar - Glass effect only for sidebar */}
      <div
        className={`${isMobile ? "w-full" : sidebarWidth} transition-all duration-300 glass-sidebar relative z-20 flex flex-col h-screen`}
      >
        {/* Header */}
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center justify-between">
            {(!isCollapsed || isMobile) && (
              <div className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm"
                  style={{ background: currentTheme.gradients.primary }}
                >
                  G
                </div>
                <span className="font-bold text-lg text-white">Glofy</span>
              </div>
            )}
            <div className="flex items-center gap-2">
              {!isMobile && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsCollapsed(!isCollapsed)}
                  className="h-8 w-8 p-0 rounded-lg text-white/70 hover:text-white"
                >
                  {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
                </Button>
              )}
              {isMobile && onClose && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="h-8 w-8 p-0 rounded-lg text-white/70 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 p-4 space-y-2">
          {[
            { icon: Home, label: "Dashboard", view: "dashboard" as const, color: currentTheme.colors.primary },
            { icon: MessageCircle, label: "Chat", view: "chat" as const, color: currentTheme.colors.secondary },
            { icon: Settings, label: "Settings", view: "settings" as const, color: currentTheme.colors.accent },
          ].map((item, index) => (
            <Button
              key={index}
              variant="ghost"
              onClick={() => handleViewChange(item.view)}
              className={`w-full justify-start rounded-xl h-12 text-sm font-medium transition-all duration-200 ${
                activeView === item.view
                  ? "text-white shadow-lg transform scale-[1.02]"
                  : "text-white hover:transform hover:scale-[1.01] hover:shadow-md"
              }`}
              style={{
                background:
                  activeView === item.view
                    ? `linear-gradient(135deg, ${item.color} 0%, ${item.color}80 100%)`
                    : `linear-gradient(135deg, ${item.color}60 0%, ${item.color}40 100%)`,
                border: activeView === item.view ? `1px solid ${item.color}60` : `1px solid ${item.color}30`,
                boxShadow:
                  activeView === item.view
                    ? `0 4px 16px ${item.color}40, inset 0 1px 0 rgba(255, 255, 255, 0.2)`
                    : `0 2px 8px ${item.color}20, inset 0 1px 0 rgba(255, 255, 255, 0.1)`,
              }}
              onMouseEnter={(e) => {
                if (activeView !== item.view) {
                  e.currentTarget.style.background = `linear-gradient(135deg, ${item.color}80 0%, ${item.color}60 100%)`
                  e.currentTarget.style.border = `1px solid ${item.color}50`
                  e.currentTarget.style.boxShadow = `0 4px 12px ${item.color}30, inset 0 1px 0 rgba(255, 255, 255, 0.15)`
                }
              }}
              onMouseLeave={(e) => {
                if (activeView !== item.view) {
                  e.currentTarget.style.background = `linear-gradient(135deg, ${item.color}60 0%, ${item.color}40 100%)`
                  e.currentTarget.style.border = `1px solid ${item.color}30`
                  e.currentTarget.style.boxShadow = `0 2px 8px ${item.color}20, inset 0 1px 0 rgba(255, 255, 255, 0.1)`
                }
              }}
            >
              <item.icon className="h-5 w-5 text-white" />
              {(!isCollapsed || isMobile) && <span className="ml-3">{item.label}</span>}
            </Button>
          ))}
        </div>

        <Separator className="bg-white/10" />

        {/* User Profile */}
        <div className="p-4">
          {!isCollapsed || isMobile ? (
            <Card
              className="backdrop-blur-sm border"
              style={{
                backgroundColor: `${currentTheme.colors.surface}60`,
                borderColor: `${currentTheme.colors.border}30`,
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold text-sm"
                    style={{ background: currentTheme.gradients.primary }}
                  >
                    {currentUser.username.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: currentTheme.colors.text }}>
                      {currentUser.displayName}
                    </p>
                    <p className="text-xs truncate" style={{ color: currentTheme.colors.textMuted }}>
                      Access granted
                    </p>
                  </div>
                </div>
                <Button
                  onClick={handleSignOut}
                  variant="outline"
                  size="sm"
                  className="w-full rounded-lg text-sm bg-transparent h-10 transition-all duration-200 hover:transform hover:scale-[1.02]"
                  style={{
                    borderColor: `${currentTheme.colors.border}50`,
                    color: currentTheme.colors.textSecondary,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = `${currentTheme.colors.error}20`
                    e.currentTarget.style.borderColor = `${currentTheme.colors.error}40`
                    e.currentTarget.style.color = currentTheme.colors.error
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = "transparent"
                    e.currentTarget.style.borderColor = `${currentTheme.colors.border}50`
                    e.currentTarget.style.color = currentTheme.colors.textSecondary
                  }}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-white font-semibold text-sm mx-auto"
                style={{ background: currentTheme.gradients.primary }}
              >
                {currentUser.username.charAt(0).toUpperCase()}
              </div>
              <Button
                onClick={handleSignOut}
                variant="ghost"
                size="sm"
                className="w-full h-8 p-0 rounded-lg text-white/70 hover:text-white transition-all duration-200"
                style={{
                  color: currentTheme.colors.textSecondary,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = `${currentTheme.colors.error}20`
                  e.currentTarget.style.color = currentTheme.colors.error
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "transparent"
                  e.currentTarget.style.color = currentTheme.colors.textSecondary
                }}
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
