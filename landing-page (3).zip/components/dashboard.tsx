"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useTheme } from "@/contexts/theme-context"
import { AppSidebar } from "@/components/app-sidebar"
import { DynamicBackground } from "@/components/dynamic-background"
import {
  Send,
  MessageCircle,
  User,
  Bot,
  Loader2,
  Settings,
  History,
  MoreHorizontal,
  Trash2,
  Plus,
  Menu,
  Zap,
} from "lucide-react"
import { SettingsDashboard } from "@/components/settings-dashboard"
import { ColorsDashboard } from "@/components/colors-dashboard"
import { StylesDashboard } from "@/components/styles-dashboard"
import { ProfileSettings } from "@/components/profile-settings"
import { useAuth } from "@/hooks/useAuth"
import { useChats, type ChatMessage } from "@/hooks/useChats"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Function to format text with markdown-style bold formatting
const formatMessageContent = (content: string) => {
  // Replace **text** and *text* with bold formatting
  const formattedContent = content
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") // **bold**
    .replace(/\*(.*?)\*/g, "<strong>$1</strong>") // *bold*

  return formattedContent
}

// Component to render formatted message content
const MessageContent = ({ content }: { content: string }) => {
  const formattedContent = formatMessageContent(content)

  return (
    <p
      className="text-sm sm:text-sm leading-relaxed whitespace-pre-wrap break-words"
      dangerouslySetInnerHTML={{ __html: formattedContent }}
    />
  )
}

export function Dashboard() {
  const { currentTheme } = useTheme()
  const { getCurrentUser } = useAuth()
  const {
    chats,
    currentChat,
    createNewChat,
    addMessageToChat,
    updateMessageInChat,
    updateChatTitle,
    switchToChat,
    deleteChat,
    currentChatId,
  } = useChats()
  const currentUser = getCurrentUser()
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [activeView, setActiveView] = useState<"dashboard" | "chat" | "settings">("dashboard")
  const [settingsPanel, setSettingsPanel] = useState<"colors" | "styles" | "profile" | null>(null)
  const [showChatHistory, setShowChatHistory] = useState(false)
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [currentChat?.messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    // Create new chat if none exists
    let chatId = currentChat?.id
    if (!chatId) {
      chatId = createNewChat()
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: input,
      timestamp: new Date(),
      sender: "user",
    }

    addMessageToChat(chatId, userMessage)
    const currentInput = input
    setInput("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            ...(currentChat?.messages || []).map((m) => ({
              role: m.sender === "user" ? "user" : "assistant",
              content: m.content,
            })),
            { role: "user", content: currentInput },
          ],
        }),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
      }

      if (!response.body) {
        throw new Error("No response body received")
      }

      const reader = response.body.getReader()
      const decoder = new TextDecoder()

      let aiResponse = ""
      const aiMessageId = (Date.now() + 1).toString()

      // Add empty AI message that we'll update
      const aiMessage: ChatMessage = {
        id: aiMessageId,
        content: "",
        timestamp: new Date(),
        sender: "ai",
      }
      addMessageToChat(chatId, aiMessage)

      try {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value, { stream: true })
          const lines = chunk.split("\n")

          for (const line of lines) {
            if (line.trim() && line.startsWith("0:")) {
              try {
                const data = JSON.parse(line.slice(2))
                if (data.type === "text-delta" && data.textDelta) {
                  aiResponse += data.textDelta
                  updateMessageInChat(chatId, aiMessageId, aiResponse)
                }
              } catch (parseError) {
                console.warn("Failed to parse chunk:", line, parseError)
              }
            }
          }
        }
      } finally {
        reader.releaseLock()
      }

      // If no response was received, add a fallback message
      if (!aiResponse.trim()) {
        updateMessageInChat(
          chatId,
          aiMessageId,
          "I apologize, but I didn't receive a proper response. Please try your question again.",
        )
      }

      // Generate AI title after the conversation has some content
      setTimeout(() => {
        updateChatTitle(chatId)
      }, 1000)
    } catch (error) {
      console.error("Chat error:", error)
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        content:
          error instanceof Error
            ? `Sorry, there was an issue: ${error.message}. Please try again.`
            : "Sorry, I'm having trouble connecting right now. Please try again in a moment.",
        timestamp: new Date(),
        sender: "ai",
      }
      addMessageToChat(chatId, errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString([], { month: "short", day: "numeric" })
  }

  const handleStartChat = () => {
    setActiveView("chat")
    if (!currentChat) {
      createNewChat()
    }
  }

  const handleChatSelect = (chatId: string) => {
    switchToChat(chatId)
    setActiveView("chat")
    setShowChatHistory(false)
  }

  const handleDeleteChat = (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    deleteChat(chatId)
  }

  return (
    <div className="min-h-screen max-h-screen flex relative overflow-hidden">
      {/* Dynamic Background */}
      <DynamicBackground />

      {/* Mobile Sidebar Overlay */}
      {isMobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setIsMobileSidebarOpen(false)}
          />

          {/* Mobile Sidebar */}
          <div className="relative w-80 max-w-[90vw] h-full bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl shadow-2xl">
            <AppSidebar
              activeView={activeView}
              onViewChange={(view) => {
                setActiveView(view)
                setIsMobileSidebarOpen(false)
              }}
              isMobile={true}
              onClose={() => setIsMobileSidebarOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <AppSidebar activeView={activeView} onViewChange={setActiveView} />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative z-10 overflow-hidden w-full min-w-0">
        {/* Header - Regular themed header */}
        <div
          className="border-b backdrop-blur-xl p-3 sm:p-4 flex-shrink-0 min-h-[60px] sm:min-h-[72px]"
          style={{
            backgroundColor: `${currentTheme.colors.surface}80`,
            borderColor: `${currentTheme.colors.border}30`,
          }}
        >
          <div className="flex items-center justify-between h-full">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMobileSidebarOpen(true)}
                className="lg:hidden h-9 w-9 sm:h-10 sm:w-10 p-0 rounded-lg flex-shrink-0"
                style={{ color: currentTheme.colors.textMuted }}
              >
                <Menu className="h-4 w-4 sm:h-5 sm:w-5" />
              </Button>

              <div className="min-w-0 flex-1">
                <h1
                  className="text-lg sm:text-xl lg:text-2xl font-bold truncate"
                  style={{ color: currentTheme.colors.text }}
                >
                  {activeView === "dashboard" && !showChatHistory && "Welcome to Glofy!"}
                  {activeView === "dashboard" && showChatHistory && "Chat History"}
                  {activeView === "chat" && (currentChat?.title || "AI Assistant")}
                  {activeView === "settings" && "Settings"}
                </h1>
                <p className="text-xs sm:text-sm truncate" style={{ color: currentTheme.colors.textSecondary }}>
                  {activeView === "dashboard" &&
                    !showChatHistory &&
                    "Powered by Glofy-1 • Enhanced with Google Gemini web search"}
                  {activeView === "dashboard" &&
                    showChatHistory &&
                    `${chats.length} conversation${chats.length !== 1 ? "s" : ""}`}
                  {activeView === "chat" && "Glofy-1 AI with real-time Google web search"}
                  {activeView === "settings" && "Customize your Glofy experience"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
              {activeView === "chat" && (
                <Button
                  onClick={() => setShowChatHistory(true)}
                  variant="outline"
                  size="sm"
                  className="rounded-lg text-xs sm:text-sm px-2 sm:px-3 h-8 sm:h-10"
                  style={{
                    borderColor: `${currentTheme.colors.border}50`,
                    color: currentTheme.colors.textSecondary,
                  }}
                >
                  <History className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
                  <span className="hidden sm:inline">History</span>
                </Button>
              )}
              {showChatHistory && (
                <Button
                  onClick={() => setShowChatHistory(false)}
                  variant="outline"
                  size="sm"
                  className="rounded-lg text-xs sm:text-sm px-2 sm:px-3 h-8 sm:h-10"
                  style={{
                    borderColor: `${currentTheme.colors.border}50`,
                    color: currentTheme.colors.textSecondary,
                  }}
                >
                  <span className="hidden sm:inline">Back to Dashboard</span>
                  <span className="sm:hidden">Back</span>
                </Button>
              )}

              <div className="flex items-center gap-2 sm:gap-3">
                <div
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-white font-semibold text-xs sm:text-sm"
                  style={{ background: currentTheme.gradients.primary }}
                >
                  {currentUser.username.charAt(0).toUpperCase()}
                </div>
                <div className="text-right hidden md:block">
                  <p className="text-sm font-medium truncate max-w-24" style={{ color: currentTheme.colors.text }}>
                    {currentUser.displayName}
                  </p>
                  <p className="text-xs" style={{ color: currentTheme.colors.textMuted }}>
                    Online
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-3 sm:p-4 lg:p-6 overflow-hidden min-h-0 relative">
          {activeView === "dashboard" && (
            <div className="h-full flex flex-col">
              {/* Dashboard Stats Row - Glass themed cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 mb-4 sm:mb-6 flex-shrink-0">
                {/* Profile Card */}
                <div className="glass-dashboard-card p-3 sm:p-4">
                  <div className="flex items-center gap-3">
                    <User
                      className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0"
                      style={{ color: currentTheme.colors.primary }}
                    />
                    <div className="min-w-0 flex-1">
                      <h3
                        className="font-semibold text-sm sm:text-base truncate"
                        style={{ color: currentTheme.colors.text }}
                      >
                        {currentUser.displayName}
                      </h3>
                      <p className="text-xs sm:text-sm" style={{ color: currentTheme.colors.textSecondary }}>
                        Active today
                      </p>
                    </div>
                  </div>
                </div>

                {/* Chat Stats Card */}
                <div className="glass-dashboard-card p-3 sm:p-4">
                  <div className="flex items-center gap-3">
                    <MessageCircle
                      className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0"
                      style={{ color: currentTheme.colors.primary }}
                    />
                    <div className="min-w-0 flex-1">
                      <h3
                        className="font-semibold text-sm sm:text-base truncate"
                        style={{ color: currentTheme.colors.text }}
                      >
                        {chats.length} Conversations
                      </h3>
                      <p className="text-xs sm:text-sm" style={{ color: currentTheme.colors.textSecondary }}>
                        Chat history available
                      </p>
                    </div>
                  </div>
                </div>

                {/* Glofy-1 Status Card */}
                <div className="glass-dashboard-card p-3 sm:p-4 sm:col-span-2 lg:col-span-1">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Zap
                        className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0"
                        style={{ color: currentTheme.colors.success }}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3
                        className="font-semibold text-sm sm:text-base truncate"
                        style={{ color: currentTheme.colors.text }}
                      >
                        Glofy-1 + Google Web Search
                      </h3>
                      <p className="text-xs sm:text-sm" style={{ color: currentTheme.colors.textSecondary }}>
                        Real-time accurate information
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Main Content Area */}
              {!showChatHistory ? (
                // Welcome Section - Glass effect for main welcome card
                <div className="flex-1 flex items-center justify-center px-2">
                  <div className="w-full max-w-lg glass-welcome-card text-center p-6 sm:p-8">
                    <div className="relative mb-4 sm:mb-6">
                      <div
                        className="w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center mx-auto text-white text-2xl sm:text-3xl font-bold"
                        style={{ background: currentTheme.gradients.primary }}
                      >
                        G
                      </div>
                    </div>
                    <h2
                      className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3"
                      style={{ color: currentTheme.colors.text }}
                    >
                      Welcome to Glofy AI!
                    </h2>
                    <p
                      className="text-sm sm:text-base mb-6 sm:mb-8"
                      style={{ color: currentTheme.colors.textSecondary }}
                    >
                      Your productivity assistant is now powered by Glofy-1 AI with real-time Google web search via
                      Gemini. Get current, accurate information, productivity insights, and intelligent assistance.
                    </p>
                    <div className="grid grid-cols-1 gap-3 sm:gap-4">
                      <Button
                        onClick={handleStartChat}
                        className="w-full text-white py-3 sm:py-3 text-sm sm:text-base h-12 sm:h-12"
                        style={{ background: currentTheme.gradients.primary }}
                      >
                        <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3" />
                        Start AI Chat
                      </Button>
                      <Button
                        onClick={() => setShowChatHistory(true)}
                        variant="outline"
                        className="w-full py-3 sm:py-3 text-sm sm:text-base h-12 sm:h-12"
                        style={{
                          borderColor: `${currentTheme.colors.border}50`,
                          color: currentTheme.colors.textSecondary,
                        }}
                      >
                        <History className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3" />
                        View Chat History ({chats.length})
                      </Button>
                      <Button
                        onClick={() => setActiveView("settings")}
                        variant="outline"
                        className="w-full py-3 sm:py-3 text-sm sm:text-base h-12 sm:h-12"
                        style={{
                          borderColor: `${currentTheme.colors.border}50`,
                          color: currentTheme.colors.textSecondary,
                        }}
                      >
                        <Settings className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3" />
                        Customize Experience
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                // Chat History Section - Regular themed
                <div className="flex-1 flex flex-col min-h-0">
                  <div className="flex flex-col gap-3 sm:gap-4 mb-4 sm:mb-6">
                    <div>
                      <h2 className="text-lg sm:text-xl font-bold" style={{ color: currentTheme.colors.text }}>
                        Your Conversations
                      </h2>
                      <p className="text-xs sm:text-sm" style={{ color: currentTheme.colors.textSecondary }}>
                        {chats.length} chat{chats.length !== 1 ? "s" : ""} • Powered by Glofy-1 + Google Search • Click
                        any chat to continue
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                      <Button
                        onClick={() => {
                          createNewChat()
                          setActiveView("chat")
                        }}
                        className="text-white text-sm sm:text-base px-4 h-10 sm:h-12"
                        style={{ background: currentTheme.gradients.primary }}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        New AI Chat
                      </Button>
                      <Button
                        onClick={() => setShowChatHistory(false)}
                        variant="outline"
                        className="text-sm sm:text-base px-4 h-10 sm:h-12"
                        style={{
                          borderColor: `${currentTheme.colors.border}50`,
                          color: currentTheme.colors.textSecondary,
                        }}
                      >
                        Back to Dashboard
                      </Button>
                    </div>
                  </div>

                  {/* Chat Grid - Glass themed cards */}
                  <div className="flex-1 overflow-y-auto custom-scrollbar">
                    {chats.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center py-8 sm:py-12 px-4">
                        <div
                          className="w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mb-3 sm:mb-4 relative"
                          style={{ backgroundColor: `${currentTheme.colors.primary}20` }}
                        >
                          <MessageCircle
                            className="w-6 h-6 sm:w-8 sm:h-8"
                            style={{ color: currentTheme.colors.primary }}
                          />
                        </div>
                        <h3
                          className="text-base sm:text-lg font-semibold mb-2"
                          style={{ color: currentTheme.colors.text }}
                        >
                          No conversations yet
                        </h3>
                        <p className="text-xs sm:text-sm mb-4 sm:mb-6" style={{ color: currentTheme.colors.textMuted }}>
                          Start your first chat with Glofy-1 AI for intelligent productivity assistance with real-time
                          Google web search.
                        </p>
                        <Button
                          onClick={() => {
                            createNewChat()
                            setActiveView("chat")
                          }}
                          className="text-white text-sm sm:text-base h-10 sm:h-12"
                          style={{ background: currentTheme.gradients.primary }}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Start AI Chat
                        </Button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4 pb-4">
                        {chats.map((chat) => (
                          <div
                            key={chat.id}
                            className="glass-dashboard-card cursor-pointer group p-4 sm:p-5"
                            onClick={() => handleChatSelect(chat.id)}
                          >
                            <div className="flex items-start justify-between mb-3">
                              <div className="relative">
                                <div
                                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center text-white font-semibold flex-shrink-0"
                                  style={{ background: currentTheme.gradients.primary }}
                                >
                                  <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                                </div>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-6 w-6 sm:h-8 sm:w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <MoreHorizontal className="w-3 h-3 sm:w-4 sm:h-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem
                                    onClick={(e) => handleDeleteChat(chat.id, e)}
                                    className="text-red-600 dark:text-red-400"
                                  >
                                    <Trash2 className="w-4 h-4 mr-2" />
                                    Delete Chat
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>

                            <h4
                              className="font-semibold text-sm sm:text-base mb-2 line-clamp-2"
                              style={{ color: currentTheme.colors.text }}
                            >
                              {chat.title}
                            </h4>

                            <div className="flex items-center justify-between text-xs sm:text-sm">
                              <span style={{ color: currentTheme.colors.textSecondary }}>
                                {chat.messages.length - 1} message{chat.messages.length - 1 !== 1 ? "s" : ""}
                              </span>
                              <span style={{ color: currentTheme.colors.textMuted }}>{formatDate(chat.updatedAt)}</span>
                            </div>

                            {/* Preview of last message */}
                            {chat.messages.length > 1 && (
                              <div
                                className="mt-3 pt-3 border-t"
                                style={{ borderColor: `${currentTheme.colors.border}30` }}
                              >
                                <p className="text-xs line-clamp-2" style={{ color: currentTheme.colors.textMuted }}>
                                  {chat.messages[chat.messages.length - 1]?.content.substring(0, 100)}...
                                </p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Chat View - Glass themed */}
          {activeView === "chat" && (
            <div className="h-full flex flex-col overflow-hidden">
              {/* Chat Interface */}
              <div className="glass-chat-container h-full flex flex-col">
                <div className="pb-2 sm:pb-3 flex-shrink-0 px-3 sm:px-4 lg:px-6 pt-3 sm:pt-4 lg:pt-6">
                  <div
                    className="text-base sm:text-lg lg:text-xl flex items-center gap-2"
                    style={{ color: currentTheme.colors.text }}
                  >
                    <div className="relative">
                      <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 flex-shrink-0" />
                    </div>
                    <span className="truncate min-w-0">{currentChat?.title || "Glofy-1 AI Assistant"}</span>
                    <span
                      className="text-xs px-2 py-1 rounded-full flex items-center gap-1 flex-shrink-0"
                      style={{
                        backgroundColor: `${currentTheme.colors.success}20`,
                        color: currentTheme.colors.success,
                      }}
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                      <span>Live</span>
                    </span>
                  </div>
                </div>
                <div className="h-px" style={{ backgroundColor: `${currentTheme.colors.border}50` }} />

                {/* Messages Container */}
                <div className="flex-1 min-h-0 relative">
                  <div className="absolute inset-0 overflow-y-auto p-3 sm:p-4 custom-scrollbar">
                    <div className="space-y-3 sm:space-y-4 pb-4">
                      {(currentChat?.messages || []).map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div className="flex items-start gap-2 sm:gap-3 max-w-[90%] sm:max-w-[85%] lg:max-w-[80%]">
                            {message.sender === "ai" && (
                              <div className="relative">
                                <div
                                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-semibold flex-shrink-0 mt-1 shadow-lg"
                                  style={{ background: currentTheme.gradients.secondary }}
                                >
                                  <Bot className="w-3 h-3 sm:w-4 sm:h-4" />
                                </div>
                              </div>
                            )}
                            <div
                              className={`rounded-2xl px-3 sm:px-4 py-2 sm:py-3 shadow-sm hover:shadow-md transition-shadow duration-200 ${
                                message.sender === "user" ? "rounded-br-sm" : "rounded-bl-sm"
                              }`}
                              style={{
                                backgroundColor:
                                  message.sender === "user"
                                    ? currentTheme.colors.primary
                                    : `${currentTheme.colors.surface}90`,
                                color: message.sender === "user" ? "#ffffff" : currentTheme.colors.text,
                                border: message.sender === "ai" ? `1px solid ${currentTheme.colors.border}50` : "none",
                              }}
                            >
                              <MessageContent content={message.content} />
                              <p className="text-xs mt-1 sm:mt-2 opacity-70">{formatTime(message.timestamp)}</p>
                            </div>
                            {message.sender === "user" && (
                              <div
                                className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-semibold flex-shrink-0 mt-1 shadow-lg"
                                style={{ background: currentTheme.gradients.primary }}
                              >
                                {currentUser.username.charAt(0).toUpperCase()}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                      {isLoading && (
                        <div className="flex justify-start">
                          <div className="flex items-start gap-2 sm:gap-3 max-w-[90%] sm:max-w-[85%] lg:max-w-[80%]">
                            <div className="relative">
                              <div
                                className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-semibold flex-shrink-0 mt-1 shadow-lg"
                                style={{ background: currentTheme.gradients.secondary }}
                              >
                                <Bot className="w-3 h-3 sm:w-4 sm:h-4" />
                              </div>
                            </div>
                            <div
                              className="rounded-2xl rounded-bl-sm px-3 sm:px-4 py-2 sm:py-3 border shadow-sm"
                              style={{
                                backgroundColor: `${currentTheme.colors.surface}90`,
                                borderColor: `${currentTheme.colors.border}50`,
                              }}
                            >
                              <div className="flex items-center gap-2">
                                <Loader2
                                  className="w-3 h-3 sm:w-4 sm:h-4 animate-spin"
                                  style={{ color: currentTheme.colors.primary }}
                                />
                                <span
                                  className="text-xs sm:text-sm"
                                  style={{ color: currentTheme.colors.textSecondary }}
                                >
                                  Searching the web & thinking...
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div ref={messagesEndRef} />
                  </div>
                </div>

                {/* Message Input */}
                <div
                  className="p-3 sm:p-4 border-t flex-shrink-0"
                  style={{ borderColor: `${currentTheme.colors.border}30` }}
                >
                  <form onSubmit={handleSubmit} className="flex gap-2 sm:gap-3">
                    <Input
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Ask me anything - I'll search Google for current information..."
                      className="flex-1 rounded-xl backdrop-blur-sm text-sm sm:text-sm h-11 sm:h-12"
                      style={{
                        backgroundColor: `${currentTheme.colors.surface}80`,
                        borderColor: `${currentTheme.colors.border}50`,
                        color: currentTheme.colors.text,
                        fontSize: "16px", // Prevents zoom on iOS
                      }}
                      disabled={isLoading}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault()
                          handleSubmit(e)
                        }
                      }}
                    />
                    <Button
                      type="submit"
                      size="icon"
                      className="rounded-xl text-white h-11 w-11 sm:h-12 sm:w-12 flex-shrink-0"
                      style={{ background: currentTheme.gradients.primary }}
                      disabled={!input.trim() || isLoading}
                    >
                      {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </Button>
                  </form>
                  <p className="text-xs mt-2 text-center" style={{ color: currentTheme.colors.textMuted }}>
                    Powered by Glofy-1 AI • Enhanced with Google Gemini web search
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Settings View */}
          {activeView === "settings" && (
            <div className="h-full overflow-y-auto custom-scrollbar">
              <SettingsDashboard
                onColorSettings={() => setSettingsPanel("colors")}
                onStyleSettings={() => setSettingsPanel("styles")}
                onProfileSettings={() => setSettingsPanel("profile")}
              />
            </div>
          )}
        </div>

        {/* Settings Panels */}
        {activeView === "settings" && (
          <>
            <ColorsDashboard isOpen={settingsPanel === "colors"} onClose={() => setSettingsPanel(null)} />
            <StylesDashboard isOpen={settingsPanel === "styles"} onClose={() => setSettingsPanel(null)} />
            <ProfileSettings isOpen={settingsPanel === "profile"} onClose={() => setSettingsPanel(null)} />
          </>
        )}
      </div>
    </div>
  )
}
