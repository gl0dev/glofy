-- Function to sign in with username
CREATE OR REPLACE FUNCTION sign_in_with_username(username_input TEXT, password_input TEXT)
RETURNS JSON AS $$
DECLARE
  user_email TEXT;
  result JSON;
BEGIN
  -- Get email from user_profiles
  SELECT u.email INTO user_email
  FROM auth.users u
  JOIN public.user_profiles p ON u.id = p.id
  WHERE p.username = LOWER(username_input);
  
  IF user_email IS NULL THEN
    RETURN json_build_object('success', false, 'message', 'Invalid username or password');
  END IF;
  
  RETURN json_build_object('success', true, 'email', user_email);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check username availability
CREATE OR REPLACE FUNCTION check_username_available(username_input TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM public.user_profiles 
    WHERE username = LOWER(username_input)
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
