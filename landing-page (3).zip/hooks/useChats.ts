"use client"

import { useState, useEffect } from "react"
import { useAuth } from "./useAuth"

export interface ChatMessage {
  id: string
  content: string
  timestamp: Date
  sender: "user" | "ai"
}

export interface Chat {
  id: string
  title: string
  messages: ChatMessage[]
  createdAt: Date
  updatedAt: Date
}

export function useChats() {
  const { getCurrentUser } = useAuth()
  const [chats, setChats] = useState<Chat[]>([])
  const [currentChatId, setCurrentChatId] = useState<string | null>(null)
  const currentUser = getCurrentUser()

  // Load chats from localStorage on mount
  useEffect(() => {
    if (currentUser?.username) {
      const savedChats = localStorage.getItem(`glofy-chats-${currentUser.username}`)
      if (savedChats) {
        try {
          const parsedChats = JSON.parse(savedChats).map((chat: any) => ({
            ...chat,
            createdAt: new Date(chat.createdAt),
            updatedAt: new Date(chat.updatedAt),
            messages: chat.messages.map((msg: any) => ({
              ...msg,
              timestamp: new Date(msg.timestamp),
            })),
          }))
          setChats(parsedChats)

          // Set the most recent chat as current if no chat is selected
          if (parsedChats.length > 0) {
            setCurrentChatId(parsedChats[0].id)
          }
        } catch (error) {
          console.error("Error loading chats:", error)
        }
      }
    }
  }, [currentUser?.username])

  // Save chats to localStorage whenever chats change
  useEffect(() => {
    if (currentUser?.username && chats.length > 0) {
      localStorage.setItem(`glofy-chats-${currentUser.username}`, JSON.stringify(chats))
    }
  }, [chats, currentUser?.username])

  const generateChatTitleWithAI = async (messages: ChatMessage[]): Promise<string> => {
    try {
      // Filter out welcome messages and get meaningful conversation
      const conversationMessages = messages.filter(
        (msg) => msg.sender === "user" || (msg.sender === "ai" && !msg.content.includes("Hi, I'm")),
      )

      if (conversationMessages.length < 2) {
        return "New Chat"
      }

      const response = await fetch("/api/generate-title", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: conversationMessages.map((msg) => ({
            role: msg.sender === "user" ? "user" : "assistant",
            content: msg.content,
          })),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate title")
      }

      const { title } = await response.json()
      return title || "New Chat"
    } catch (error) {
      console.error("Error generating chat title:", error)
      // Fallback to simple title generation
      const firstUserMessage = messages.find((msg) => msg.sender === "user")
      if (!firstUserMessage) return "New Chat"

      const content = firstUserMessage.content.trim()
      if (content.length <= 30) {
        return content
      } else {
        const words = content.split(" ").filter((word) => word.length > 3)
        if (words.length > 0) {
          return words.slice(0, 3).join(" ") + "..."
        } else {
          return content.substring(0, 30) + "..."
        }
      }
    }
  }

  const createNewChat = (): string => {
    const newChat: Chat = {
      id: `chat-${Date.now()}`,
      title: "New Chat",
      messages: [
        {
          id: "welcome",
          content:
            "Hi, I'm Glofy! I'm your AI productivity assistant powered by Glofy-1 with real-time Google web search capabilities via Gemini AI. I can help you with current information, productivity strategies, creative problem-solving, and much more. I have access to live web data and can provide up-to-date, accurate insights. What would you like to explore today?",
          timestamp: new Date(),
          sender: "ai",
        },
      ],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    setChats((prev) => [newChat, ...prev])
    setCurrentChatId(newChat.id)
    return newChat.id
  }

  const addMessageToChat = (chatId: string, message: ChatMessage) => {
    setChats((prev) =>
      prev.map((chat) => {
        if (chat.id === chatId) {
          const updatedMessages = [...chat.messages, message]
          const updatedChat = {
            ...chat,
            messages: updatedMessages,
            updatedAt: new Date(),
          }
          return updatedChat
        }
        return chat
      }),
    )
  }

  const updateMessageInChat = (chatId: string, messageId: string, content: string) => {
    setChats((prev) =>
      prev.map((chat) => {
        if (chat.id === chatId) {
          return {
            ...chat,
            messages: chat.messages.map((msg) => (msg.id === messageId ? { ...msg, content } : msg)),
            updatedAt: new Date(),
          }
        }
        return chat
      }),
    )
  }

  const updateChatTitle = async (chatId: string) => {
    const chat = chats.find((c) => c.id === chatId)
    if (!chat) return

    // Only generate title if it's still "New Chat" and we have enough messages
    if (chat.title === "New Chat" && chat.messages.length >= 3) {
      const newTitle = await generateChatTitleWithAI(chat.messages)

      setChats((prev) => prev.map((c) => (c.id === chatId ? { ...c, title: newTitle } : c)))
    }
  }

  const deleteChat = (chatId: string) => {
    setChats((prev) => {
      const updatedChats = prev.filter((chat) => chat.id !== chatId)

      // If we're deleting the current chat, switch to another one or clear
      if (currentChatId === chatId) {
        if (updatedChats.length > 0) {
          setCurrentChatId(updatedChats[0].id)
        } else {
          setCurrentChatId(null)
        }
      }

      return updatedChats
    })
  }

  const getCurrentChat = (): Chat | null => {
    return chats.find((chat) => chat.id === currentChatId) || null
  }

  const switchToChat = (chatId: string) => {
    const chatExists = chats.find((chat) => chat.id === chatId)
    if (chatExists) {
      setCurrentChatId(chatId)
    }
  }

  return {
    chats,
    currentChatId,
    currentChat: getCurrentChat(),
    createNewChat,
    addMessageToChat,
    updateMessageInChat,
    updateChatTitle,
    deleteChat,
    switchToChat,
  }
}
