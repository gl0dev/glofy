export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Filter out system messages and get conversation content
    const conversationMessages = messages.filter((msg: any) => msg.role !== "system")

    if (conversationMessages.length === 0) {
      return Response.json({ title: "New Chat" })
    }

    // Get the first user message to generate a title
    const firstUserMessage = conversationMessages.find((msg: any) => msg.role === "user")

    if (!firstUserMessage) {
      return Response.json({ title: "New Chat" })
    }

    // Generate title based on keywords in the first message
    const content = firstUserMessage.content.toLowerCase()
    let title = "New Chat"

    // More comprehensive title generation
    if (content.match(/\b(hi|hello|hey|greet)/)) {
      title = "Getting Started"
    } else if (content.match(/\b(question|what|how|why|explain)/)) {
      title = "Q&A Session"
    } else if (content.match(/\b(problem|help|issue|trouble|stuck)/)) {
      title = "Problem Solving"
    } else if (content.match(/\b(create|design|write|idea|brainstorm)/)) {
      title = "Creative Project"
    } else if (content.match(/\b(learn|study|understand|teach)/)) {
      title = "Learning Session"
    } else if (content.match(/\b(feel|emotion|personal|life)/)) {
      title = "Personal Chat"
    } else if (content.match(/\b(computer|tech|software|app)/)) {
      title = "Tech Support"
    } else if (content.match(/\b(health|fitness|wellness)/)) {
      title = "Health & Wellness"
    } else if (content.match(/\b(relationship|friend|family)/)) {
      title = "Relationships"
    } else if (content.match(/\b(work|job|career|business)/)) {
      title = "Career Discussion"
    } else if (content.match(/\b(hobby|interest|fun|game)/)) {
      title = "Hobbies & Interests"
    } else if (content.match(/\b(task|todo|productive|organize)/)) {
      title = "Productivity"
    } else if (content.match(/\b(time|schedule|plan)/)) {
      title = "Planning"
    } else if (content.match(/\b(goal|objective|achieve)/)) {
      title = "Goals"
    } else {
      // Extract key words and create a simple title
      const words = content
        .split(" ")
        .filter(
          (word) =>
            word.length > 3 &&
            ![
              "what",
              "how",
              "can",
              "you",
              "help",
              "with",
              "about",
              "the",
              "and",
              "for",
              "are",
              "this",
              "that",
              "would",
              "could",
              "should",
            ].includes(word),
        )

      if (words.length > 0) {
        title = words
          .slice(0, 2)
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")
      } else {
        title = "General Chat"
      }
    }

    return Response.json({ title })
  } catch (error) {
    console.error("Title generation error:", error)
    return Response.json({ title: "New Chat" })
  }
}
