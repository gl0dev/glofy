"use client"

import { useState, useEffect } from "react"

interface UserProfile {
  username: string
  displayName: string
  accessKey: string
}

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user has entered the correct key
    const savedAuth = localStorage.getItem("glofy-authenticated")
    if (savedAuth === "true") {
      setIsAuthenticated(true)
    }
    setLoading(false)
  }, [])

  const getStoredProfiles = (): Record<string, UserProfile> => {
    const stored = localStorage.getItem("glofy-user-profiles")
    if (stored) {
      try {
        return JSON.parse(stored)
      } catch {
        return {}
      }
    }
    return {}
  }

  const saveStoredProfiles = (profiles: Record<string, UserProfile>) => {
    localStorage.setItem("glofy-user-profiles", JSON.stringify(profiles))
  }

  const getDefaultUsers = (): Record<string, UserProfile> => {
    return {
      glokey: { username: "glo", displayName: "Glo", accessKey: "glokey" },
      kell: { username: "KELL", displayName: "KELL", accessKey: "kell" },
      abdullah: { username: "abdullah", displayName: "Abadi", accessKey: "abdullah" },
      bassel: { username: "bassel", displayName: "Bassel", accessKey: "bassel" },
    }
  }

  const getAllUsers = (): Record<string, UserProfile> => {
    const defaultUsers = getDefaultUsers()
    const storedProfiles = getStoredProfiles()

    // Merge default users with stored profiles, giving priority to stored profiles
    const allUsers = { ...defaultUsers }

    Object.values(storedProfiles).forEach((profile) => {
      allUsers[profile.accessKey] = profile
    })

    return allUsers
  }

  const enterKey = async (key: string) => {
    const users = getAllUsers()

    if (users[key]) {
      const user = users[key]
      setIsAuthenticated(true)
      localStorage.setItem("glofy-authenticated", "true")
      localStorage.setItem("glofy-current-user", JSON.stringify(user))
      return { success: true, error: null, user }
    } else {
      return { success: false, error: { message: "Invalid access key" } }
    }
  }

  const updateUserProfile = async (updates: {
    displayName: string
    currentKey?: string
    newKey?: string
    confirmKey?: string
  }) => {
    const currentUser = getCurrentUser()
    if (!currentUser) {
      return { success: false, error: "No user logged in" }
    }

    const { displayName, currentKey, newKey, confirmKey } = updates

    // Validate display name
    if (!displayName.trim()) {
      return { success: false, error: "Display name cannot be empty" }
    }

    // If changing access key, validate the process
    if (newKey || confirmKey || currentKey) {
      if (!currentKey) {
        return { success: false, error: "Current access key is required to change key" }
      }

      if (!newKey) {
        return { success: false, error: "New access key is required" }
      }

      if (!confirmKey) {
        return { success: false, error: "Please confirm your new access key" }
      }

      if (newKey !== confirmKey) {
        return { success: false, error: "New access keys do not match" }
      }

      if (currentKey !== currentUser.accessKey) {
        return { success: false, error: "Current access key is incorrect" }
      }

      // Check if new key already exists
      const allUsers = getAllUsers()
      if (allUsers[newKey] && newKey !== currentUser.accessKey) {
        return { success: false, error: "This access key is already in use" }
      }
    }

    try {
      const storedProfiles = getStoredProfiles()
      const updatedUser: UserProfile = {
        ...currentUser,
        displayName: displayName.trim(),
        accessKey: newKey || currentUser.accessKey,
      }

      // Remove old profile if key changed
      if (newKey && newKey !== currentUser.accessKey) {
        delete storedProfiles[currentUser.accessKey]
      }

      // Save updated profile
      storedProfiles[updatedUser.accessKey] = updatedUser
      saveStoredProfiles(storedProfiles)

      // Update current user in localStorage
      localStorage.setItem("glofy-current-user", JSON.stringify(updatedUser))

      return { success: true, error: null }
    } catch (error) {
      return { success: false, error: "Failed to save profile changes" }
    }
  }

  const signOut = async () => {
    setIsAuthenticated(false)
    localStorage.removeItem("glofy-authenticated")
    localStorage.removeItem("glofy-current-user")
    // Force a page reload to go back to the landing page
    window.location.reload()
    return { error: null }
  }

  const getCurrentUser = (): UserProfile => {
    const savedUser = localStorage.getItem("glofy-current-user")
    if (savedUser) {
      try {
        return JSON.parse(savedUser)
      } catch {
        return { username: "glo", displayName: "Glo", accessKey: "glokey" } // fallback
      }
    }
    return { username: "glo", displayName: "Glo", accessKey: "glokey" } // default
  }

  return {
    isAuthenticated,
    loading,
    enterKey,
    signOut,
    getCurrentUser,
    updateUserProfile,
  }
}
