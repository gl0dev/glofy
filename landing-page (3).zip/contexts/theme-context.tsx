"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export interface BackgroundStyle {
  id: string
  name: string
  type: "gradient" | "pattern" | "waves" | "particles" | "mesh"
  component: React.ComponentType<{ theme: Theme }>
}

export interface Theme {
  id: string
  name: string
  colors: {
    primary: string
    primaryHover: string
    secondary: string
    secondaryHover: string
    background: string
    backgroundSecondary: string
    surface: string
    surfaceHover: string
    text: string
    textSecondary: string
    textMuted: string
    border: string
    accent: string
    accentHover: string
    success: string
    error: string
    warning: string
  }
  gradients: {
    primary: string
    secondary: string
    background: string
    accent: string
  }
  backgroundStyle: string
}

// Background Components
const GradientBackground: React.FC<{ theme: Theme }> = ({ theme }) => (
  <div className="absolute inset-0" style={{ background: theme.gradients.background }} />
)

const PatternBackground: React.FC<{ theme: Theme }> = ({ theme }) => (
  <div className="absolute inset-0" style={{ background: theme.gradients.background }}>
    <div
      className="absolute inset-0 opacity-10"
      style={{
        backgroundImage: `radial-gradient(circle at 25% 25%, ${theme.colors.primary} 2px, transparent 2px), radial-gradient(circle at 75% 75%, ${theme.colors.secondary} 2px, transparent 2px)`,
        backgroundSize: "50px 50px",
      }}
    />
  </div>
)

const WavesBackground: React.FC<{ theme: Theme }> = ({ theme }) => (
  <div className="absolute inset-0" style={{ background: theme.gradients.background }}>
    <svg className="absolute bottom-0 w-full h-64 opacity-20" viewBox="0 0 1200 320" preserveAspectRatio="none">
      <path
        fill={theme.colors.primary}
        d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,138.7C960,139,1056,117,1152,106.7C1248,96,1344,96,1392,96L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
      />
    </svg>
    <svg className="absolute bottom-0 w-full h-64 opacity-15" viewBox="0 0 1200 320" preserveAspectRatio="none">
      <path
        fill={theme.colors.secondary}
        d="M0,192L48,197.3C96,203,192,213,288,208C384,203,480,181,576,170.7C672,160,768,160,864,165.3C960,171,1056,181,1152,186.7C1248,192,1344,192,1392,192L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
      />
    </svg>
    <svg className="absolute top-0 w-full h-64 opacity-25 rotate-180" viewBox="0 0 1200 320" preserveAspectRatio="none">
      <path
        fill={theme.colors.accent}
        d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,138.7C960,139,1056,117,1152,106.7C1248,96,1344,96,1392,96L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
      />
    </svg>
  </div>
)

const GridBackground: React.FC<{ theme: Theme }> = ({ theme }) => (
  <div className="absolute inset-0" style={{ background: theme.gradients.background }}>
    <div
      className="absolute inset-0 opacity-10"
      style={{
        backgroundImage: `
          linear-gradient(${theme.colors.primary} 1px, transparent 1px),
          linear-gradient(90deg, ${theme.colors.primary} 1px, transparent 1px)
        `,
        backgroundSize: "30px 30px",
      }}
    />
    <div
      className="absolute inset-0 opacity-5"
      style={{
        backgroundImage: `
          linear-gradient(${theme.colors.secondary} 1px, transparent 1px),
          linear-gradient(90deg, ${theme.colors.secondary} 1px, transparent 1px)
        `,
        backgroundSize: "60px 60px",
      }}
    />
  </div>
)

const MeshBackground: React.FC<{ theme: Theme }> = ({ theme }) => (
  <div className="absolute inset-0" style={{ background: theme.gradients.background }}>
    <div className="absolute inset-0 opacity-30">
      <div
        className="absolute top-0 left-0 w-96 h-96 rounded-full blur-3xl"
        style={{ background: `radial-gradient(circle, ${theme.colors.primary}40 0%, transparent 70%)` }}
      />
      <div
        className="absolute top-1/4 right-0 w-80 h-80 rounded-full blur-3xl"
        style={{ background: `radial-gradient(circle, ${theme.colors.secondary}40 0%, transparent 70%)` }}
      />
      <div
        className="absolute bottom-0 left-1/3 w-72 h-72 rounded-full blur-3xl"
        style={{ background: `radial-gradient(circle, ${theme.colors.accent}40 0%, transparent 70%)` }}
      />
      <div
        className="absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full blur-3xl"
        style={{ background: `radial-gradient(circle, ${theme.colors.primary}30 0%, transparent 70%)` }}
      />
    </div>
  </div>
)

export const backgroundStyles: BackgroundStyle[] = [
  { id: "gradient", name: "Gradient", type: "gradient", component: GradientBackground },
  { id: "pattern", name: "Dotted Pattern", type: "pattern", component: PatternBackground },
  { id: "waves", name: "Waves", type: "waves", component: WavesBackground },
  { id: "mesh", name: "Mesh Gradient", type: "mesh", component: MeshBackground },
  { id: "grid", name: "Grid", type: "pattern", component: GridBackground },
]

// Default theme definitions
const getDefaultLightThemes = (): Theme[] => [
  {
    id: "clean",
    name: "Clean",
    backgroundStyle: "gradient",
    colors: {
      primary: "#3b82f6",
      primaryHover: "#2563eb",
      secondary: "#0055ff", // Changed from "#64748b"
      secondaryHover: "#475569",
      background: "#ffffff",
      backgroundSecondary: "#f8fafc",
      surface: "#ffffff",
      surfaceHover: "#f8fafc",
      text: "#0f172a",
      textSecondary: "#475569",
      textMuted: "#64748b",
      border: "#e2e8f0",
      accent: "#3b82f6",
      accentHover: "#2563eb",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #3b82f6 0%, #0055ff 100%)", // Updated gradient
      secondary: "linear-gradient(135deg, #0055ff 0%, #3b82f6 100%)", // Updated gradient
      background: "linear-gradient(135deg, #ffffff 0%, #f8fafc 50%, #f1f5f9 100%)",
      accent: "linear-gradient(135deg, #3b82f6 0%, #0055ff 100%)", // Updated gradient
    },
  },
  {
    id: "default",
    name: "Ocean Blue",
    backgroundStyle: "gradient",
    colors: {
      primary: "#2563eb",
      primaryHover: "#1d4ed8",
      secondary: "#8b5cf6",
      secondaryHover: "#7c3aed",
      background: "#f1f5f9",
      backgroundSecondary: "#e2e8f0",
      surface: "#ffffff",
      surfaceHover: "#f8fafc",
      text: "#1e293b",
      textSecondary: "#475569",
      textMuted: "#64748b",
      border: "#e2e8f0",
      accent: "#06b6d4",
      accentHover: "#0891b2",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #2563eb 0%, #8b5cf6 100%)",
      secondary: "linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)",
      background: "linear-gradient(135deg, #f1f5f9 0%, #ddd6fe 50%, #e0e7ff 100%)",
      accent: "linear-gradient(135deg, #06b6d4 0%, #3b82f6 100%)",
    },
  },
  {
    id: "sunset",
    name: "Sunset Orange",
    backgroundStyle: "waves",
    colors: {
      primary: "#ea580c",
      primaryHover: "#dc2626",
      secondary: "#f59e0b",
      secondaryHover: "#d97706",
      background: "#fef7ed",
      backgroundSecondary: "#fed7aa",
      surface: "#ffffff",
      surfaceHover: "#fffbeb",
      text: "#1c1917",
      textSecondary: "#57534e",
      textMuted: "#78716c",
      border: "#fed7aa",
      accent: "#f97316",
      accentHover: "#ea580c",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #ea580c 0%, #f59e0b 100%)",
      secondary: "linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%)",
      background: "linear-gradient(135deg, #fef7ed 0%, #fed7aa 50%, #fde68a 100%)",
      accent: "linear-gradient(135deg, #f97316 0%, #ea580c 100%)",
    },
  },
  {
    id: "forest",
    name: "Forest Green",
    backgroundStyle: "pattern",
    colors: {
      primary: "#059669",
      primaryHover: "#047857",
      secondary: "#10b981",
      secondaryHover: "#059669",
      background: "#f0fdf4",
      backgroundSecondary: "#bbf7d0",
      surface: "#ffffff",
      surfaceHover: "#f7fee7",
      text: "#14532d",
      textSecondary: "#166534",
      textMuted: "#4ade80",
      border: "#bbf7d0",
      accent: "#22c55e",
      accentHover: "#16a34a",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
      secondary: "linear-gradient(135deg, #10b981 0%, #22c55e 100%)",
      background: "linear-gradient(135deg, #f0fdf4 0%, #bbf7d0 50%, #dcfce7 100%)",
      accent: "linear-gradient(135deg, #22c55e 0%, #059669 100%)",
    },
  },
  {
    id: "rose",
    name: "Rose Gold",
    backgroundStyle: "mesh",
    colors: {
      primary: "#e11d48",
      primaryHover: "#be123c",
      secondary: "#f97316",
      secondaryHover: "#ea580c",
      background: "#fdf2f8",
      backgroundSecondary: "#fce7f3",
      surface: "#ffffff",
      surfaceHover: "#fef7f0",
      text: "#881337",
      textSecondary: "#9f1239",
      textMuted: "#f43f5e",
      border: "#fce7f3",
      accent: "#ec4899",
      accentHover: "#db2777",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #e11d48 0%, #f97316 100%)",
      secondary: "linear-gradient(135deg, #f97316 0%, #ec4899 100%)",
      background: "linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fef7f0 100%)",
      accent: "linear-gradient(135deg, #ec4899 0%, #e11d48 100%)",
    },
  },
  {
    id: "amber",
    name: "Amber Glow",
    backgroundStyle: "grid",
    colors: {
      primary: "#d97706",
      primaryHover: "#b45309",
      secondary: "#f59e0b",
      secondaryHover: "#d97706",
      background: "#fffbeb",
      backgroundSecondary: "#fef3c7",
      surface: "#ffffff",
      surfaceHover: "#fefce8",
      text: "#78350f",
      textSecondary: "#92400e",
      textMuted: "#fbbf24",
      border: "#fef3c7",
      accent: "#f97316",
      accentHover: "#ea580c",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #d97706 0%, #f59e0b 100%)",
      secondary: "linear-gradient(135deg, #f59e0b 0%, #f97316 100%)",
      background: "linear-gradient(135deg, #fffbeb 0%, #fef3c7 50%, #fefce8 100%)",
      accent: "linear-gradient(135deg, #f97316 0%, #d97706 100%)",
    },
  },
  {
    id: "sakura",
    name: "Sakura Bloom",
    backgroundStyle: "pattern",
    colors: {
      primary: "#ec4899",
      primaryHover: "#db2777",
      secondary: "#f472b6",
      secondaryHover: "#ec4899",
      background: "#fdf2f8",
      backgroundSecondary: "#fce7f3",
      surface: "#ffffff",
      surfaceHover: "#fef7f3",
      text: "#831843",
      textSecondary: "#9d174d",
      textMuted: "#f9a8d4",
      border: "#fce7f3",
      accent: "#a855f7",
      accentHover: "#9333ea",
      success: "#10b981",
      error: "#ef4444",
      warning: "#f59e0b",
    },
    gradients: {
      primary: "linear-gradient(135deg, #ec4899 0%, #f472b6 100%)",
      secondary: "linear-gradient(135deg, #f472b6 0%, #a855f7 100%)",
      background: "linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fef7f3 100%)",
      accent: "linear-gradient(135deg, #a855f7 0%, #ec4899 100%)",
    },
  },
]

const getDefaultDarkThemes = (): Theme[] => [
  {
    id: "dark-clean",
    name: "Clean Dark",
    backgroundStyle: "gradient",
    colors: {
      primary: "#60a5fa",
      primaryHover: "#3b82f6",
      secondary: "#64748b",
      secondaryHover: "#475569",
      background: "#0f172a",
      backgroundSecondary: "#1e293b",
      surface: "#1e293b",
      surfaceHover: "#334155",
      text: "#f8fafc",
      textSecondary: "#e2e8f0",
      textMuted: "#94a3b8",
      border: "#334155",
      accent: "#60a5fa",
      accentHover: "#3b82f6",
      success: "#34d399",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #60a5fa 0%, #64748b 100%)",
      secondary: "linear-gradient(135deg, #64748b 0%, #60a5fa 100%)",
      background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)",
      accent: "linear-gradient(135deg, #60a5fa 0%, #64748b 100%)",
    },
  },
  {
    id: "dark-ocean",
    name: "Midnight Ocean",
    backgroundStyle: "mesh",
    colors: {
      primary: "#60a5fa",
      primaryHover: "#3b82f6",
      secondary: "#a78bfa",
      secondaryHover: "#8b5cf6",
      background: "#0f172a",
      backgroundSecondary: "#1e293b",
      surface: "#334155",
      surfaceHover: "#475569",
      text: "#f8fafc",
      textSecondary: "#e2e8f0",
      textMuted: "#94a3b8",
      border: "#475569",
      accent: "#22d3ee",
      accentHover: "#06b6d4",
      success: "#34d399",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #60a5fa 0%, #a78bfa 100%)",
      secondary: "linear-gradient(135deg, #a78bfa 0%, #f472b6 100%)",
      background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)",
      accent: "linear-gradient(135deg, #22d3ee 0%, #60a5fa 100%)",
    },
  },
  {
    id: "dark-ember",
    name: "Ember Night",
    backgroundStyle: "waves",
    colors: {
      primary: "#fb7185",
      primaryHover: "#f43f5e",
      secondary: "#fbbf24",
      secondaryHover: "#f59e0b",
      background: "#1c1917",
      backgroundSecondary: "#292524",
      surface: "#44403c",
      surfaceHover: "#57534e",
      text: "#fafaf9",
      textSecondary: "#e7e5e4",
      textMuted: "#a8a29e",
      border: "#57534e",
      accent: "#fb923c",
      accentHover: "#f97316",
      success: "#4ade80",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #fb7185 0%, #fbbf24 100%)",
      secondary: "linear-gradient(135deg, #fbbf24 0%, #fb923c 100%)",
      background: "linear-gradient(135deg, #1c1917 0%, #292524 50%, #44403c 100%)",
      accent: "linear-gradient(135deg, #fb923c 0%, #fb7185 100%)",
    },
  },
  {
    id: "dark-forest",
    name: "Shadow Forest",
    backgroundStyle: "pattern",
    colors: {
      primary: "#4ade80",
      primaryHover: "#22c55e",
      secondary: "#34d399",
      secondaryHover: "#10b981",
      background: "#0c1910",
      backgroundSecondary: "#14532d",
      surface: "#166534",
      surfaceHover: "#15803d",
      text: "#f0fdf4",
      textSecondary: "#dcfce7",
      textMuted: "#bbf7d0",
      border: "#15803d",
      accent: "#06b6d4",
      accentHover: "#0891b2",
      success: "#4ade80",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #4ade80 0%, #34d399 100%)",
      secondary: "linear-gradient(135deg, #34d399 0%, #06b6d4 100%)",
      background: "linear-gradient(135deg, #0c1910 0%, #14532d 50%, #166534 100%)",
      accent: "linear-gradient(135deg, #06b6d4 0%, #4ade80 100%)",
    },
  },
  {
    id: "dark-rose",
    name: "Crimson Night",
    backgroundStyle: "mesh",
    colors: {
      primary: "#f472b6",
      primaryHover: "#ec4899",
      secondary: "#fb7185",
      secondaryHover: "#f43f5e",
      background: "#1f0a14",
      backgroundSecondary: "#4c1d24",
      surface: "#7c2d12",
      surfaceHover: "#9a3412",
      text: "#fdf2f8",
      textSecondary: "#fce7f3",
      textMuted: "#f9a8d4",
      border: "#9a3412",
      accent: "#c084fc",
      accentHover: "#a855f7",
      success: "#4ade80",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #f472b6 0%, #fb7185 100%)",
      secondary: "linear-gradient(135deg, #fb7185 0%, #c084fc 100%)",
      background: "linear-gradient(135deg, #1f0a14 0%, #4c1d24 50%, #7c2d12 100%)",
      accent: "linear-gradient(135deg, #c084fc 0%, #f472b6 100%)",
    },
  },
  {
    id: "dark-gold",
    name: "Golden Shadow",
    backgroundStyle: "grid",
    colors: {
      primary: "#fbbf24",
      primaryHover: "#f59e0b",
      secondary: "#fb923c",
      secondaryHover: "#f97316",
      background: "#1c1917",
      backgroundSecondary: "#292524",
      surface: "#44403c",
      surfaceHover: "#57534e",
      text: "#fffbeb",
      textSecondary: "#fef3c7",
      textMuted: "#fde68a",
      border: "#57534e",
      accent: "#f472b6",
      accentHover: "#ec4899",
      success: "#4ade80",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #fbbf24 0%, #fb923c 100%)",
      secondary: "linear-gradient(135deg, #fb923c 0%, #f472b6 100%)",
      background: "linear-gradient(135deg, #1c1917 0%, #292524 50%, #44403c 100%)",
      accent: "linear-gradient(135deg, #f472b6 0%, #fbbf24 100%)",
    },
  },
  {
    id: "dark-violet",
    name: "Violet Dreams",
    backgroundStyle: "pattern",
    colors: {
      primary: "#c084fc",
      primaryHover: "#a855f7",
      secondary: "#f472b6",
      secondaryHover: "#ec4899",
      background: "#1e1b4b",
      backgroundSecondary: "#312e81",
      surface: "#4c1d95",
      surfaceHover: "#5b21b6",
      text: "#faf5ff",
      textSecondary: "#e9d5ff",
      textMuted: "#c4b5fd",
      border: "#5b21b6",
      accent: "#60a5fa",
      accentHover: "#3b82f6",
      success: "#4ade80",
      error: "#f87171",
      warning: "#fbbf24",
    },
    gradients: {
      primary: "linear-gradient(135deg, #c084fc 0%, #f472b6 100%)",
      secondary: "linear-gradient(135deg, #f472b6 0%, #60a5fa 100%)",
      background: "linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%)",
      accent: "linear-gradient(135deg, #60a5fa 0%, #c084fc 100%)",
    },
  },
]

interface ThemeContextType {
  currentTheme: Theme
  themes: Theme[]
  backgroundStyles: BackgroundStyle[]
  setTheme: (themeId: string) => void
  updateThemeColor: (colorKey: keyof Theme["colors"], color: string) => void
  updateBackgroundStyle: (styleId: string) => void
  resetTheme: () => void
  createCustomTheme: (name: string, baseTheme: Theme) => void
  toggleDarkMode: () => void
  isDarkMode: boolean
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [lightThemes, setLightThemes] = useState<Theme[]>(getDefaultLightThemes())
  const [darkThemes, setDarkThemes] = useState<Theme[]>(getDefaultDarkThemes())
  const [lightThemeId, setLightThemeId] = useState("clean")
  const [darkThemeId, setDarkThemeId] = useState("dark-clean")
  const [customThemes, setCustomThemes] = useState<Theme[]>([])

  const allThemes = [...lightThemes, ...darkThemes, ...customThemes]
  const currentThemes = isDarkMode
    ? [...darkThemes, ...customThemes.filter((t) => t.id.includes("dark"))]
    : [...lightThemes, ...customThemes.filter((t) => !t.id.includes("dark"))]
  const currentThemeId = isDarkMode ? darkThemeId : lightThemeId
  const currentTheme = allThemes.find((theme) => theme.id === currentThemeId) || allThemes[0]

  useEffect(() => {
    // Load saved preferences from localStorage
    const savedDarkMode = localStorage.getItem("glofy-dark-mode")
    const savedLightTheme = localStorage.getItem("glofy-light-theme")
    const savedDarkTheme = localStorage.getItem("glofy-dark-theme")
    const savedCustomThemes = localStorage.getItem("glofy-custom-themes")
    const savedLightThemes = localStorage.getItem("glofy-light-themes")
    const savedDarkThemesStorage = localStorage.getItem("glofy-dark-themes")

    if (savedDarkMode !== null) {
      const isDark = JSON.parse(savedDarkMode)
      setIsDarkMode(isDark)
      if (isDark) {
        document.documentElement.classList.add("dark")
      }
    }

    if (savedLightTheme) {
      setLightThemeId(savedLightTheme)
    }

    if (savedDarkTheme) {
      setDarkThemeId(savedDarkTheme)
    }

    if (savedLightThemes) {
      try {
        const themes = JSON.parse(savedLightThemes)
        setLightThemes(themes)
      } catch (error) {
        console.error("Error loading light themes:", error)
      }
    }

    if (savedDarkThemesStorage) {
      try {
        const themes = JSON.parse(savedDarkThemesStorage)
        setDarkThemes(themes)
      } catch (error) {
        console.error("Error loading dark themes:", error)
      }
    }

    if (savedCustomThemes) {
      try {
        const custom = JSON.parse(savedCustomThemes)
        setCustomThemes(custom)
      } catch (error) {
        console.error("Error loading custom themes:", error)
      }
    }
  }, [])

  useEffect(() => {
    // Apply theme to CSS variables
    const root = document.documentElement
    Object.entries(currentTheme.colors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value)
    })
    Object.entries(currentTheme.gradients).forEach(([key, value]) => {
      root.style.setProperty(`--gradient-${key}`, value)
    })

    // Save current preferences
    localStorage.setItem("glofy-dark-mode", JSON.stringify(isDarkMode))
    localStorage.setItem("glofy-light-themes", JSON.stringify(lightThemes))
    localStorage.setItem("glofy-dark-themes", JSON.stringify(darkThemes))
    if (isDarkMode) {
      localStorage.setItem("glofy-dark-theme", darkThemeId)
    } else {
      localStorage.setItem("glofy-light-theme", lightThemeId)
    }
  }, [currentTheme, isDarkMode, lightThemeId, darkThemeId, lightThemes, darkThemes])

  const setTheme = (themeId: string) => {
    if (isDarkMode) {
      setDarkThemeId(themeId)
    } else {
      setLightThemeId(themeId)
    }
  }

  const updateThemeColor = (colorKey: keyof Theme["colors"], color: string) => {
    const targetThemeId = isDarkMode ? darkThemeId : lightThemeId

    if (isDarkMode) {
      setDarkThemes((prevThemes) =>
        prevThemes.map((theme) =>
          theme.id === targetThemeId
            ? {
                ...theme,
                colors: {
                  ...theme.colors,
                  [colorKey]: color,
                },
                gradients: {
                  ...theme.gradients,
                  primary:
                    colorKey === "primary" || colorKey === "secondary"
                      ? `linear-gradient(135deg, ${colorKey === "primary" ? color : theme.colors.primary} 0%, ${colorKey === "secondary" ? color : theme.colors.secondary} 100%)`
                      : theme.gradients.primary,
                  secondary:
                    colorKey === "secondary" || colorKey === "accent"
                      ? `linear-gradient(135deg, ${colorKey === "secondary" ? color : theme.colors.secondary} 0%, ${colorKey === "accent" ? color : theme.colors.accent} 100%)`
                      : theme.gradients.secondary,
                  accent:
                    colorKey === "accent" || colorKey === "primary"
                      ? `linear-gradient(135deg, ${colorKey === "accent" ? color : theme.colors.accent} 0%, ${colorKey === "primary" ? color : theme.colors.primary} 100%)`
                      : theme.gradients.accent,
                },
              }
            : theme,
        ),
      )
    } else {
      setLightThemes((prevThemes) =>
        prevThemes.map((theme) =>
          theme.id === targetThemeId
            ? {
                ...theme,
                colors: {
                  ...theme.colors,
                  [colorKey]: color,
                },
                gradients: {
                  ...theme.gradients,
                  primary:
                    colorKey === "primary" || colorKey === "secondary"
                      ? `linear-gradient(135deg, ${colorKey === "primary" ? color : theme.colors.primary} 0%, ${colorKey === "secondary" ? color : theme.colors.secondary} 100%)`
                      : theme.gradients.primary,
                  secondary:
                    colorKey === "secondary" || colorKey === "accent"
                      ? `linear-gradient(135deg, ${colorKey === "secondary" ? color : theme.colors.secondary} 0%, ${colorKey === "accent" ? color : theme.colors.accent} 100%)`
                      : theme.gradients.secondary,
                  accent:
                    colorKey === "accent" || colorKey === "primary"
                      ? `linear-gradient(135deg, ${colorKey === "accent" ? color : theme.colors.accent} 0%, ${colorKey === "primary" ? color : theme.colors.primary} 100%)`
                      : theme.gradients.accent,
                },
              }
            : theme,
        ),
      )
    }

    // Also update custom themes if applicable
    setCustomThemes((prevCustomThemes) =>
      prevCustomThemes.map((theme) =>
        theme.id === targetThemeId
          ? {
              ...theme,
              colors: {
                ...theme.colors,
                [colorKey]: color,
              },
              gradients: {
                ...theme.gradients,
                primary:
                  colorKey === "primary" || colorKey === "secondary"
                    ? `linear-gradient(135deg, ${colorKey === "primary" ? color : theme.colors.primary} 0%, ${colorKey === "secondary" ? color : theme.colors.secondary} 100%)`
                    : theme.gradients.primary,
                secondary:
                  colorKey === "secondary" || colorKey === "accent"
                    ? `linear-gradient(135deg, ${colorKey === "secondary" ? color : theme.colors.secondary} 0%, ${colorKey === "accent" ? color : theme.colors.accent} 100%)`
                    : theme.gradients.secondary,
                accent:
                  colorKey === "accent" || colorKey === "primary"
                    ? `linear-gradient(135deg, ${colorKey === "accent" ? color : theme.colors.accent} 0%, ${colorKey === "primary" ? color : theme.colors.primary} 100%)`
                    : theme.gradients.accent,
              },
            }
          : theme,
      ),
    )
  }

  const updateBackgroundStyle = (styleId: string) => {
    const targetThemeId = isDarkMode ? darkThemeId : lightThemeId

    if (isDarkMode) {
      setDarkThemes((prevThemes) =>
        prevThemes.map((theme) => (theme.id === targetThemeId ? { ...theme, backgroundStyle: styleId } : theme)),
      )
    } else {
      setLightThemes((prevThemes) =>
        prevThemes.map((theme) => (theme.id === targetThemeId ? { ...theme, backgroundStyle: styleId } : theme)),
      )
    }

    // Also update custom themes if applicable
    setCustomThemes((prevCustomThemes) =>
      prevCustomThemes.map((theme) => (theme.id === targetThemeId ? { ...theme, backgroundStyle: styleId } : theme)),
    )
  }

  const resetTheme = () => {
    const targetThemeId = isDarkMode ? darkThemeId : lightThemeId

    if (isDarkMode) {
      const defaultTheme = getDefaultDarkThemes().find((theme) => theme.id === targetThemeId)
      if (defaultTheme) {
        setDarkThemes((prevThemes) =>
          prevThemes.map((theme) => (theme.id === targetThemeId ? { ...defaultTheme } : theme)),
        )
      }
    } else {
      const defaultTheme = getDefaultLightThemes().find((theme) => theme.id === targetThemeId)
      if (defaultTheme) {
        setLightThemes((prevThemes) =>
          prevThemes.map((theme) => (theme.id === targetThemeId ? { ...defaultTheme } : theme)),
        )
      }
    }
  }

  const createCustomTheme = (name: string, baseTheme: Theme) => {
    const customTheme: Theme = {
      ...baseTheme,
      id: `custom-${Date.now()}`,
      name,
    }

    setCustomThemes((prev) => [...prev, customTheme])

    // Set as current theme
    if (isDarkMode) {
      setDarkThemeId(customTheme.id)
    } else {
      setLightThemeId(customTheme.id)
    }
  }

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)

    if (newDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }

  return (
    <ThemeContext.Provider
      value={{
        currentTheme,
        themes: currentThemes,
        backgroundStyles,
        setTheme,
        updateThemeColor,
        updateBackgroundStyle,
        resetTheme,
        createCustomTheme,
        toggleDarkMode,
        isDarkMode,
      }}
    >
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
