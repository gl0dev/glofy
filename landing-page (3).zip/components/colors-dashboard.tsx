"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { X, Palette, RefreshCw, Plus, Check, Sun, Moon, Zap, Leaf, Crown, Sparkles } from "lucide-react"
import { useTheme, type Theme } from "@/contexts/theme-context"

interface ColorsDashboardProps {
  isOpen: boolean
  onClose: () => void
}

const themeIcons = {
  // Light themes
  clean: Sun,
  default: Sun,
  sunset: Zap,
  forest: Leaf,
  rose: Crown,
  amber: Zap,
  sakura: Crown,
  // Dark themes
  "dark-clean": Moon,
  "dark-ocean": Moon,
  "dark-ember": Zap,
  "dark-forest": Leaf,
  "dark-rose": Crown,
  "dark-gold": Zap,
  "dark-violet": Sparkles,
}

export function ColorsDashboard({ isOpen, onClose }: ColorsDashboardProps) {
  const { currentTheme, themes, setTheme, updateThemeColor, resetTheme, createCustomTheme, isDarkMode } = useTheme()
  const [customThemeName, setCustomThemeName] = useState("")
  const [showCreateForm, setShowCreateForm] = useState(false)

  const handleColorChange = (colorKey: keyof Theme["colors"], color: string) => {
    updateThemeColor(colorKey, color)
  }

  const handleCreateCustomTheme = () => {
    if (customThemeName.trim()) {
      createCustomTheme(customThemeName, currentTheme)
      setCustomThemeName("")
      setShowCreateForm(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={onClose} />

      {/* Dashboard */}
      <div className="relative ml-auto h-full w-96 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-l border-white/30 dark:border-gray-700/30 shadow-2xl overflow-hidden">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200/50 dark:border-gray-700/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <Palette className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Colors</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {isDarkMode ? "Dark mode themes" : "Light mode themes"}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-10 w-10 p-0 rounded-full text-gray-500 dark:text-gray-400"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Theme Presets */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Theme Presets</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowCreateForm(!showCreateForm)}
                  className="text-xs"
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Create
                </Button>
              </div>

              {showCreateForm && (
                <Card className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-white/30 dark:border-gray-700/30">
                  <CardContent className="p-4 space-y-3">
                    <Input
                      placeholder="Custom theme name"
                      value={customThemeName}
                      onChange={(e) => setCustomThemeName(e.target.value)}
                      className="h-9"
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleCreateCustomTheme} className="flex-1">
                        Create Theme
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setShowCreateForm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid gap-3">
                {themes.map((theme) => {
                  const IconComponent = themeIcons[theme.id as keyof typeof themeIcons] || Palette
                  const isActive = currentTheme.id === theme.id

                  return (
                    <Card
                      key={theme.id}
                      className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                        isActive
                          ? "ring-2 ring-blue-500 bg-blue-50/50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700"
                          : "bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-white/30 dark:border-gray-700/30 hover:bg-white/90 dark:hover:bg-gray-800/90"
                      }`}
                      onClick={() => setTheme(theme.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className="w-10 h-10 rounded-lg flex items-center justify-center text-white"
                              style={{ background: theme.gradients.primary }}
                            >
                              <IconComponent className="w-5 h-5" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900 dark:text-gray-100">{theme.name}</h4>
                              <div className="flex gap-1 mt-1">
                                {Object.values(theme.colors)
                                  .slice(0, 4)
                                  .map((color, index) => (
                                    <div
                                      key={index}
                                      className="w-3 h-3 rounded-full border border-white/50"
                                      style={{ backgroundColor: color }}
                                    />
                                  ))}
                              </div>
                            </div>
                          </div>
                          {isActive && <Check className="w-5 h-5 text-blue-600" />}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>

            <Separator />

            {/* Color Customization */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Color Customization</h3>
                <Button variant="outline" size="sm" onClick={resetTheme}>
                  <RefreshCw className="w-3 h-3 mr-1" />
                  Reset
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Primary Colors</h4>
                  <div className="grid gap-3">
                    <ColorPicker
                      label="Primary"
                      color={currentTheme.colors.primary}
                      onChange={(color) => handleColorChange("primary", color)}
                    />
                    <ColorPicker
                      label="Secondary"
                      color={currentTheme.colors.secondary}
                      onChange={(color) => handleColorChange("secondary", color)}
                    />
                    <ColorPicker
                      label="Accent"
                      color={currentTheme.colors.accent}
                      onChange={(color) => handleColorChange("accent", color)}
                    />
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Background Colors</h4>
                  <div className="grid gap-3">
                    <ColorPicker
                      label="Background"
                      color={currentTheme.colors.background}
                      onChange={(color) => handleColorChange("background", color)}
                    />
                    <ColorPicker
                      label="Surface"
                      color={currentTheme.colors.surface}
                      onChange={(color) => handleColorChange("surface", color)}
                    />
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Text Colors</h4>
                  <div className="grid gap-3">
                    <ColorPicker
                      label="Text Primary"
                      color={currentTheme.colors.text}
                      onChange={(color) => handleColorChange("text", color)}
                    />
                    <ColorPicker
                      label="Text Secondary"
                      color={currentTheme.colors.textSecondary}
                      onChange={(color) => handleColorChange("textSecondary", color)}
                    />
                    <ColorPicker
                      label="Text Muted"
                      color={currentTheme.colors.textMuted}
                      onChange={(color) => handleColorChange("textMuted", color)}
                    />
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Status Colors</h4>
                  <div className="grid gap-3">
                    <ColorPicker
                      label="Success"
                      color={currentTheme.colors.success}
                      onChange={(color) => handleColorChange("success", color)}
                    />
                    <ColorPicker
                      label="Error"
                      color={currentTheme.colors.error}
                      onChange={(color) => handleColorChange("error", color)}
                    />
                    <ColorPicker
                      label="Warning"
                      color={currentTheme.colors.warning}
                      onChange={(color) => handleColorChange("warning", color)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

interface ColorPickerProps {
  label: string
  color: string
  onChange: (color: string) => void
}

function ColorPicker({ label, color, onChange }: ColorPickerProps) {
  return (
    <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-gray-200/50 dark:border-gray-700/50">
      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
      <div className="flex items-center gap-2">
        <div className="relative">
          <div
            className="w-8 h-8 rounded-lg border-2 border-gray-300 dark:border-gray-600 cursor-pointer shadow-sm hover:shadow-md transition-shadow"
            style={{ backgroundColor: color }}
          />
          <input
            type="color"
            value={color}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            title="Click to open color picker"
          />
        </div>
        <Input
          type="text"
          value={color}
          onChange={(e) => onChange(e.target.value)}
          className="w-24 h-8 text-xs font-mono bg-white/70 dark:bg-gray-800/70 border-gray-200/50 dark:border-gray-700/50 text-gray-900 dark:text-gray-100"
          placeholder="#000000"
        />
      </div>
    </div>
  )
}
